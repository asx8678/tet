#!/usr/bin/env bash
set -euo pipefail

# Demo assumes `tet` is on PATH and the current directory is a real local repo.
# For automated tests, run inside a fixture repository.

command -v tet >/dev/null || { echo "tet not found on PATH"; exit 1; }
command -v jq >/dev/null || { echo "jq not found on PATH"; exit 1; }

printf '\n== init ==\n'
tet init . --trust

printf '\n== doctor ==\n'
tet doctor

printf '\n== chat ==\n'
S_CHAT=$(tet session new . --mode chat --json | jq -r '.data.session.short_id // .session.short_id')
tet ask "$S_CHAT" "what does this repo do?" --json >/tmp/tet_chat.json

printf '\n== explore ==\n'
S_EXPLORE=$(tet session new . --mode explore --json | jq -r '.data.session.short_id // .session.short_id')
tet explore "$S_EXPLORE" "find the main entrypoint and summarize the project structure" --json >/tmp/tet_explore.json

printf '\n== execute edit ==\n'
S_EXEC=$(tet session new . --mode execute --json | jq -r '.data.session.short_id // .session.short_id')
set +e
tet edit "$S_EXEC" "add a short one-paragraph project summary to README.md" --json >/tmp/tet_edit.json
code=$?
set -e
if [ "$code" -ne 3 ]; then
  echo "Expected tet edit to exit 3 waiting for approval, got $code"
  exit 1
fi

printf '\n== approval ==\n'
tet approvals "$S_EXEC"
APPROVAL_ID=$(tet approvals "$S_EXEC" --json | jq -r '.data.approvals[0].short_id // .approvals[0].short_id')
tet patch approve "$APPROVAL_ID"

printf '\n== verify ==\n'
tet verify "$S_EXEC" mix_test || true

printf '\n== explain/status ==\n'
tet explain "$S_EXEC"
tet status "$S_EXEC"

printf '\nDemo completed.\n'
