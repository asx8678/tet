-- Tet SQLite schema v1 planning baseline.
-- Convert into migrations before implementation.

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_migrations (
  version INTEGER PRIMARY KEY,
  applied_at TEXT NOT NULL
);

CREATE TABLE workspaces (
  id TEXT PRIMARY KEY,
  short_id TEXT NOT NULL UNIQUE,
  name TEXT,
  root_path TEXT NOT NULL UNIQUE,
  tet_dir_path TEXT NOT NULL,
  trust_state TEXT NOT NULL CHECK (trust_state IN ('trusted', 'untrusted')),
  allow_globs_json TEXT NOT NULL DEFAULT '["**"]',
  deny_globs_json TEXT NOT NULL DEFAULT '[]',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE sessions (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  short_id TEXT NOT NULL,
  title TEXT,
  mode TEXT NOT NULL CHECK (mode IN ('chat', 'explore', 'execute')),
  category TEXT,
  agent_profile TEXT,
  status TEXT NOT NULL CHECK (status IN ('idle', 'running', 'waiting_approval', 'complete', 'error', 'cancelled')),
  provider TEXT,
  model TEXT,
  active_task_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE(workspace_id, short_id)
);

CREATE TABLE tasks (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  short_id TEXT NOT NULL,
  title TEXT NOT NULL,
  category TEXT,
  status TEXT NOT NULL CHECK (status IN ('active', 'complete', 'cancelled')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE(session_id, short_id)
);

CREATE TABLE messages (
  id TEXT PRIMARY KEY,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('system', 'user', 'assistant', 'tool')),
  content TEXT NOT NULL,
  created_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE artifacts (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT REFERENCES sessions(id) ON DELETE CASCADE,
  short_id TEXT NOT NULL,
  kind TEXT NOT NULL,
  privacy TEXT NOT NULL DEFAULT 'private',
  path TEXT,
  inline_content BLOB,
  sha256 TEXT NOT NULL,
  size_bytes INTEGER NOT NULL DEFAULT 0,
  media_type TEXT,
  redacted INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE(workspace_id, short_id)
);

CREATE TABLE events (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT REFERENCES sessions(id) ON DELETE CASCADE,
  seq INTEGER NOT NULL,
  type TEXT NOT NULL,
  schema_version INTEGER NOT NULL DEFAULT 1,
  event_version INTEGER NOT NULL DEFAULT 1,
  payload_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL,
  UNIQUE(session_id, seq)
);

CREATE TABLE workflows (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  task_id TEXT REFERENCES tasks(id) ON DELETE SET NULL,
  status TEXT NOT NULL CHECK (status IN ('running', 'paused_for_approval', 'completed', 'failed', 'cancelled')),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE workflow_steps (
  id TEXT PRIMARY KEY,
  workflow_id TEXT NOT NULL REFERENCES workflows(id) ON DELETE CASCADE,
  step_name TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  input_json TEXT NOT NULL DEFAULT '{}',
  output_json TEXT,
  status TEXT NOT NULL CHECK (status IN ('started', 'committed', 'failed', 'cancelled')),
  attempt INTEGER NOT NULL DEFAULT 1,
  started_at TEXT NOT NULL,
  committed_at TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE(workflow_id, idempotency_key)
);

CREATE TABLE tool_runs (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  task_id TEXT REFERENCES tasks(id) ON DELETE SET NULL,
  workflow_id TEXT REFERENCES workflows(id) ON DELETE SET NULL,
  tool_name TEXT NOT NULL,
  read_or_write TEXT NOT NULL CHECK (read_or_write IN ('read', 'write')),
  args_json TEXT NOT NULL DEFAULT '{}',
  args_safe_summary TEXT,
  status TEXT NOT NULL CHECK (status IN ('proposed', 'blocked', 'waiting_approval', 'running', 'success', 'error', 'cancelled')),
  block_reason TEXT,
  changed_files_json TEXT NOT NULL DEFAULT '[]',
  started_at TEXT,
  finished_at TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE context_snapshots (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  short_id TEXT NOT NULL,
  artifact_id TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
  context_hash TEXT NOT NULL,
  included_files_json TEXT NOT NULL DEFAULT '[]',
  skipped_files_json TEXT NOT NULL DEFAULT '[]',
  truncated_files_json TEXT NOT NULL DEFAULT '[]',
  redaction_json TEXT NOT NULL DEFAULT '{}',
  byte_count INTEGER NOT NULL DEFAULT 0,
  estimated_tokens INTEGER,
  created_at TEXT NOT NULL,
  metadata_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE(workspace_id, short_id)
);

CREATE TABLE provider_calls (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  workflow_id TEXT REFERENCES workflows(id) ON DELETE SET NULL,
  message_id TEXT REFERENCES messages(id) ON DELETE SET NULL,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  provider_request_id TEXT,
  prompt_hash TEXT NOT NULL,
  prompt_debug_artifact_id TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
  context_snapshot_id TEXT REFERENCES context_snapshots(id) ON DELETE SET NULL,
  raw_request_artifact_id TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
  raw_response_artifact_id TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
  status TEXT NOT NULL CHECK (status IN ('started', 'success', 'error', 'timeout', 'cancelled')),
  finish_reason TEXT,
  input_tokens INTEGER,
  output_tokens INTEGER,
  total_tokens INTEGER,
  estimated_cost TEXT,
  latency_ms INTEGER,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  error_reason TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE patch_sets (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  task_id TEXT REFERENCES tasks(id) ON DELETE SET NULL,
  workflow_id TEXT REFERENCES workflows(id) ON DELETE SET NULL,
  tool_run_id TEXT REFERENCES tool_runs(id) ON DELETE SET NULL,
  diff_artifact_id TEXT NOT NULL REFERENCES artifacts(id) ON DELETE RESTRICT,
  patch_sha256 TEXT NOT NULL,
  target_files_json TEXT NOT NULL DEFAULT '[]',
  before_hashes_json TEXT NOT NULL DEFAULT '{}',
  snapshot_manifest_artifact_id TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
  apply_status TEXT NOT NULL DEFAULT 'not_applied' CHECK (apply_status IN ('not_applied', 'applied', 'failed', 'rolled_back')),
  apply_result_json TEXT NOT NULL DEFAULT '{}',
  rollback_artifact_id TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
  created_at TEXT NOT NULL,
  applied_at TEXT,
  rolled_back_at TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE approvals (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  task_id TEXT REFERENCES tasks(id) ON DELETE SET NULL,
  workflow_id TEXT REFERENCES workflows(id) ON DELETE SET NULL,
  tool_run_id TEXT REFERENCES tool_runs(id) ON DELETE SET NULL,
  patch_set_id TEXT REFERENCES patch_sets(id) ON DELETE CASCADE,
  short_id TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected', 'expired')),
  reason TEXT,
  risk_summary TEXT,
  created_at TEXT NOT NULL,
  expires_at TEXT,
  resolved_at TEXT,
  resolved_by TEXT,
  resolved_surface TEXT CHECK (resolved_surface IN ('cli', 'web', 'control') OR resolved_surface IS NULL),
  metadata_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE(workspace_id, short_id)
);

CREATE TABLE verifier_runs (
  id TEXT PRIMARY KEY,
  workspace_id TEXT NOT NULL REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
  workflow_id TEXT REFERENCES workflows(id) ON DELETE SET NULL,
  patch_set_id TEXT REFERENCES patch_sets(id) ON DELETE SET NULL,
  name TEXT NOT NULL,
  command_json TEXT NOT NULL,
  working_dir TEXT NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('success', 'failure', 'timeout', 'error', 'cancelled')),
  exit_code INTEGER,
  timeout_ms INTEGER NOT NULL,
  stdout_artifact_id TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
  stderr_artifact_id TEXT REFERENCES artifacts(id) ON DELETE SET NULL,
  started_at TEXT NOT NULL,
  finished_at TEXT,
  metadata_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE error_records (
  id TEXT PRIMARY KEY,
  workspace_id TEXT REFERENCES workspaces(id) ON DELETE CASCADE,
  session_id TEXT REFERENCES sessions(id) ON DELETE CASCADE,
  workflow_id TEXT REFERENCES workflows(id) ON DELETE SET NULL,
  code TEXT NOT NULL,
  category TEXT NOT NULL,
  message TEXT NOT NULL,
  safe_to_show INTEGER NOT NULL DEFAULT 1,
  details_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL
);

CREATE INDEX idx_sessions_workspace_updated ON sessions(workspace_id, updated_at DESC);
CREATE INDEX idx_events_session_seq ON events(session_id, seq);
CREATE INDEX idx_workflows_session_status ON workflows(session_id, status, updated_at DESC);
CREATE INDEX idx_workflow_steps_workflow ON workflow_steps(workflow_id, started_at);
CREATE INDEX idx_tool_runs_session ON tool_runs(session_id, started_at DESC);
CREATE INDEX idx_approvals_session_status ON approvals(session_id, status, created_at DESC);
CREATE INDEX idx_artifacts_session_kind ON artifacts(session_id, kind, created_at DESC);
CREATE INDEX idx_provider_calls_session ON provider_calls(session_id, started_at DESC);
CREATE INDEX idx_verifier_runs_session ON verifier_runs(session_id, started_at DESC);
CREATE INDEX idx_patch_sets_session ON patch_sets(session_id, created_at DESC);
CREATE INDEX idx_error_records_session ON error_records(session_id, created_at DESC);

-- One paused approval workflow per session at a time.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_paused_workflow_per_session
ON workflows(session_id)
WHERE status = 'paused_for_approval';

INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES (1, datetime('now'));
