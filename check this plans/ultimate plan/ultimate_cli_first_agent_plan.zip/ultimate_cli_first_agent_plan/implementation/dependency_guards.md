# Implementation — Dependency Guards

## `tools/check_imports.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
ROOT="${ROOT:-.}"
status=0
fail() { echo "FAIL: $1"; status=1; }

if grep -RE 'Phoenix|Plug\.|Cowboy|TetWeb\.|Ecto\.|Tet\.Runtime' \
  --include='*.ex' --include='*.exs' \
  "$ROOT/apps/tet_core/lib" "$ROOT/apps/tet_core/test" 2>/dev/null; then
  fail "forbidden reference in tet_core"
fi

if grep -RE 'Phoenix|Plug\.|Cowboy|TetWeb\.|Tet\.CLI\.' \
  --include='*.ex' --include='*.exs' \
  "$ROOT/apps/tet_runtime/lib" "$ROOT/apps/tet_runtime/test" 2>/dev/null; then
  fail "forbidden reference in tet_runtime"
fi

if grep -RE 'Phoenix|Plug\.|Cowboy|TetWeb\.|Tet\.Store\.|Tet\.Runtime\.' \
  --include='*.ex' --include='*.exs' \
  "$ROOT/apps/tet_cli/lib" "$ROOT/apps/tet_cli/test" 2>/dev/null; then
  fail "forbidden reference in tet_cli"
fi

for app in tet_store_memory tet_store_sqlite tet_store_postgres; do
  dir="$ROOT/apps/$app"
  [ -d "$dir" ] || continue
  if grep -RE 'Phoenix|Plug\.|Cowboy|TetWeb\.|Tet\.CLI\.|Tet\.Runtime\.' \
    --include='*.ex' --include='*.exs' \
    "$dir/lib" "$dir/test" 2>/dev/null; then
    fail "forbidden reference in $app"
  fi
done

if grep -RE 'Phoenix\.PubSub' \
  --include='*.ex' --include='*.exs' \
  --exclude-dir='tet_web_phoenix' \
  "$ROOT/apps" 2>/dev/null; then
  fail "Phoenix.PubSub outside tet_web_phoenix"
fi

[ "$status" -eq 0 ] && echo "OK: source guard clean"
exit "$status"
```

## `tools/check_release_closure.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
MIX_ENV=prod mix release tet_standalone --overwrite
REL_DIR="_build/prod/rel/tet_standalone/lib"

leaked=$(ls "$REL_DIR" | grep -E '^(phoenix|phoenix_live_view|phoenix_pubsub|plug|cowboy|phoenix_html)' || true)

if [ -n "$leaked" ]; then
  echo "FAIL: forbidden libraries in tet_standalone release closure:"
  echo "$leaked"
  exit 1
fi

echo "OK: tet_standalone release closure is clean"
```

## `tools/check_phoenix_removable.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
if [ ! -d apps/tet_web_phoenix ]; then
  echo "No Phoenix app present; skip."
  exit 0
fi

tmp=$(mktemp -d)
mv apps/tet_web_phoenix "$tmp/tet_web_phoenix"
trap 'mv "$tmp/tet_web_phoenix" apps/tet_web_phoenix; rm -rf "$tmp"' EXIT

mix compile --warnings-as-errors
mix test
MIX_ENV=prod mix release tet_standalone --overwrite

echo "OK: Phoenix app removable"
```
