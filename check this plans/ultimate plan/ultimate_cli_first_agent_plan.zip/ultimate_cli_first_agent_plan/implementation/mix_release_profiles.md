# Implementation — Mix Release Profiles

## Root dependency rule

Do not add Phoenix dependencies to root apps used by `tet_standalone`.

## Release sketch

```elixir
def project do
  [
    apps_path: "apps",
    version: "0.1.0",
    releases: [
      tet_standalone: [
        applications: [
          tet_core: :permanent,
          tet_store_sqlite: :permanent,
          tet_runtime: :permanent,
          tet_cli: :permanent
        ],
        steps: [:assemble, :tar]
      ],
      tet_runtime_only: [
        applications: [
          tet_core: :permanent,
          tet_store_sqlite: :permanent,
          tet_runtime: :permanent
        ]
      ],
      tet_web_local: [
        applications: [
          tet_core: :permanent,
          tet_store_sqlite: :permanent,
          tet_runtime: :permanent,
          tet_web_phoenix: :permanent
        ]
      ]
    ]
  ]
end
```

## CLI executable

Configure `tet_cli` escript or release command so:

```bash
_build/prod/rel/tet_standalone/bin/tet doctor
```

works without Phoenix.

## Closure check

Run:

```bash
MIX_ENV=prod mix release tet_standalone --overwrite
ls _build/prod/rel/tet_standalone/lib | grep -E '^(phoenix|phoenix_live_view|phoenix_pubsub|plug|cowboy|phoenix_html)' && exit 1
```

No match is allowed.
