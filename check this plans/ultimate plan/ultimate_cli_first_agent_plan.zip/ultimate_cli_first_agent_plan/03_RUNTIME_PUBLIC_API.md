# 03 — Runtime Public API

## Purpose

The public `Tet.*` facade is the only runtime boundary available to user interfaces. It gives the CLI and optional Phoenix LiveView identical authority without coupling either surface to runtime internals.

## Facade functions

```elixir
# workspace
Tet.init_workspace(path, opts \\ [])
Tet.trust_workspace(workspace_ref, opts \\ [])
Tet.untrust_workspace(workspace_ref, opts \\ [])
Tet.get_workspace(workspace_ref, opts \\ [])
Tet.workspace_info(workspace_ref_or_path, opts \\ [])
Tet.doctor(workspace_ref_or_path \\ nil, opts \\ [])

# sessions
Tet.start_session(workspace_ref, opts \\ [])
Tet.list_sessions(workspace_ref, opts \\ [])
Tet.get_session(session_ref, opts \\ [])
Tet.status(session_ref, opts \\ [])
Tet.explain(session_ref, opts \\ [])
Tet.cancel(session_ref, reason \\ :user_cancelled, opts \\ [])

# prompts and workflows
Tet.send_prompt(session_ref, prompt, opts \\ [])
Tet.stream_prompt(session_ref, prompt, opts \\ [])
Tet.resume_workflow(session_ref, opts \\ [])

# approvals and patches
Tet.list_approvals(session_ref, opts \\ [])
Tet.get_approval(approval_ref, opts \\ [])
Tet.approve_patch(approval_ref, opts \\ [])
Tet.reject_patch(approval_ref, opts \\ [])
Tet.rollback_patch(patch_ref, opts \\ [])

# verification
Tet.list_verifiers(workspace_ref, opts \\ [])
Tet.run_verification(session_ref, verifier_name, opts \\ [])

# events/artifacts/debug
Tet.list_events(session_ref, opts \\ [])
Tet.subscribe(session_ref, opts \\ [])
Tet.list_artifacts(session_ref, opts \\ [])
Tet.get_artifact(artifact_ref, opts \\ [])
Tet.prompt_debug(session_ref, opts \\ [])
Tet.lookup(kind, short_id, opts \\ [])
```

## Return convention

All facade functions return:

```elixir
{:ok, result}
{:error, %Tet.Error{} = error}
```

No UI should need to rescue runtime exceptions for normal error handling.

## Commands

Internally, facade calls validate and dispatch typed commands:

```text
Workspace.Init
Workspace.Trust
Session.Start
Session.SendPrompt
Session.Cancel
Approval.Approve
Approval.Reject
Patch.Rollback
Verifier.Run
Artifact.Read
```

Commands are persisted or journaled when they lead to durable effects.

## Events

Events are append-only per session with monotonic sequence numbers.

Core event families:

```text
workspace.created
workspace.trusted
workspace.untrusted
session.created
session.status_changed
task.created
task.completed
message.user.saved
message.assistant.delta
message.assistant.saved
context.snapshot.created
provider.call.started
provider.call.completed
provider.call.failed
tool.requested
tool.blocked
tool.started
tool.finished
approval.created
approval.approved
approval.rejected
approval.expired
patch.apply.started
patch.applied
patch.failed
patch.rollback.started
patch.rolled_back
verifier.started
verifier.finished
workflow.step_started
workflow.step_committed
workflow.step_failed
workflow.cancelled
policy.denied
policy.modified
artifact.created
error.recorded
```

Subscribers must dedupe by event id. UI projections must tolerate duplicate delivery.

## Snapshots

Snapshots are read models, not write APIs:

```elixir
%Tet.Snapshot.Session{
  session: %Tet.Session{},
  task: %Tet.Task{} | nil,
  mode: :chat | :explore | :execute,
  status: atom(),
  active_workflow: %Tet.Workflow{} | nil,
  pending_approvals: [%Tet.Approval{}],
  recent_events: [%Tet.Event{}],
  recent_tool_runs: [%Tet.ToolRun{}],
  artifacts: [%Tet.Artifact{}],
  provider: map(),
  budget: map(),
  policy_summary: map()
}
```

CLI `tet status`, `tet session show`, and LiveView session pages use the same snapshot function.

## Control semantics

### One-shot CLI

Most commands run the runtime, perform a command, persist state/events, and exit.

Examples:

```text
tet ask SESSION "..."
tet explore SESSION "..."
tet edit SESSION "..."
tet patch approve APPROVAL_ID
```

### Interactive CLI

`tet chat SESSION` keeps the runtime process alive and streams events to the terminal.

### Optional local-control service

Post-v1, a local-control service may expose `Tet.*` over a loopback Unix socket or named pipe. This lets CLI and LiveView attach to the same long-running runtime without Phoenix owning it.

Security rules:

- loopback only by default;
- random token stored in `.tet/locks/control.token` with owner-only permissions;
- no remote bind unless explicitly configured;
- all commands still pass the same policy pipeline;
- control service is not a replacement for durable storage.

## Versioning

Events and JSON payloads include versions:

```json
{
  "schema_version": 1,
  "event_version": 1,
  "type": "tool.blocked",
  "payload": {}
}
```

Breaking changes require a migration and compatibility plan.

## Error model

`%Tet.Error{}` includes:

```elixir
%Tet.Error{
  code: :path_denied_by_trust,
  message: "Writes to config/runtime.exs are denied by workspace trust policy.",
  category: :policy,
  details: %{},
  remediation: "Run tet workspace trust . --allow ... only if you intend to permit this path.",
  safe_to_show?: true
}
```

Every user-visible error should have a code, short message, and suggested next step.
