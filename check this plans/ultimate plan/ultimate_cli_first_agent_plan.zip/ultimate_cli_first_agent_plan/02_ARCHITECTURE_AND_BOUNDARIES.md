# 02 — Architecture and Boundaries

## Architecture summary

```text
CLI commands / optional LiveView
          │
          ▼
      Tet.* facade
          │
          ▼
  command validation + policy pipeline
          │
          ▼
 durable workflow executor + event bus
          │
          ├── provider adapter
          ├── tool adapter
          ├── verifier runner
          ├── artifact writer
          └── configured store adapter
```

The runtime is the product. The CLI and Phoenix are adapters.

## Dependency graph

```text
tet_cli ───────────┐
                   ├──► tet_runtime ───► tet_core
tet_web_phoenix ───┘          │
                              ├──► tet_store_memory
                              ├──► tet_store_sqlite
                              ├──► tet_store_postgres  (future)
                              └──► provider/tool adapters
```

Forbidden references:

```text
Phoenix
Phoenix.LiveView
Phoenix.PubSub
Plug
Cowboy
TetWeb.*
```

These are forbidden everywhere except `tet_web_phoenix`.

## App responsibilities

### `tet_core`

Pure domain and contracts only:

- domain structs;
- command structs;
- event structs;
- error structs;
- IDs and short IDs;
- codecs for atom/string boundaries;
- policy contracts;
- tool/provider/store behaviours;
- patch parser types;
- approval state machine;
- redaction contract.

No filesystem IO, provider IO, database IO, Phoenix, CLI rendering, or runtime GenServers.

### `tet_runtime`

Runtime and side effects:

- public `Tet.*` facade;
- OTP supervision;
- command dispatch;
- policy pipeline;
- workflow executor;
- workflow recovery;
- event bus;
- provider adapters;
- tool registry and executor;
- local filesystem tools;
- patch application and rollback;
- verifier runner;
- prompt composer;
- context builder;
- secrets resolver;
- redaction;
- configured store dispatch;
- telemetry.

### `tet_cli`

Terminal adapter:

- argument parsing;
- interactive chat loop;
- JSON output mode;
- human rendering;
- exit code mapping;
- diff rendering;
- event tailing;
- error explanations.

It never applies patches directly and never calls runtime internals.

### `tet_store_memory`

Memory store for tests:

- implements `Tet.Store` behaviour;
- passes all contract tests;
- supports deterministic fixture setup;
- no persistence guarantees.

### `tet_store_sqlite`

Default standalone store:

- workspace-local `.tet/tet.sqlite`;
- migrations;
- artifact metadata;
- event sequence allocation;
- workflow journal;
- file locking where needed;
- safe atom decoding through `Tet.Codec`.

### `tet_store_postgres`

Optional future adapter:

- same store behaviour;
- no feature should require Postgres unless explicitly marked team/server-only;
- useful for multi-operator, remote control, hosted UI, and analytics.

### `tet_web_phoenix`

Optional web adapter:

- Phoenix endpoint;
- LiveView pages/components;
- auth/session layer;
- event subscriptions/projections;
- approval UI;
- artifact browser;
- model/provider display;
- agent profile management once profiles exist.

It never owns runtime policy or domain state.

## Public boundary

Allowed external call path:

```text
Tet.CLI.*           -> Tet.*
TetWeb.*            -> Tet.*
TetWeb.* attach RPC -> Tet.Control.Client -> Tet.* in runtime service
```

Forbidden call path:

```text
Tet.CLI.*  -> Tet.Runtime.*
Tet.CLI.*  -> Tet.Store.*
TetWeb.*   -> Tet.Runtime.*
TetWeb.*   -> Tet.Store.*
TetWeb.*   -> Tet.Tools.*
TetWeb.*   -> shell("tet ...") for normal operations
```

Shelling out to `tet` is allowed only in diagnostic screens that explicitly show the command and never mutate state.

## Runtime supervision tree

```text
Tet.Application
├── Tet.Telemetry
├── Tet.Config.Loader
├── Tet.Secrets.Supervisor
├── Tet.Store.Supervisor                    starts configured store adapter
├── Tet.EventBus                            fanout; not source of truth
├── Tet.Runtime.SessionRegistry             unique registry by session id
├── Tet.Runtime.CommandSupervisor           validates and routes facade commands
├── Tet.Runtime.WorkflowSupervisor          DynamicSupervisor for workflow executors
├── Tet.Runtime.WorkflowRecovery            one-shot on boot; then idle
├── Tet.LLM.TaskSupervisor                  bounded provider stream tasks
├── Tet.Tool.TaskSupervisor                 bounded tool execution
└── Tet.Verification.TaskSupervisor         bounded verifier execution
```

No `SessionWorker` is allowed to be a source of truth. A session process may fan out or route commands, but durable state lives in storage and workflow steps.

## Release profiles

### `tet_standalone`

Includes:

```text
tet_core
tet_runtime
tet_cli
tet_store_sqlite
selected provider adapter(s)
```

Excludes:

```text
tet_web_phoenix
Phoenix
Phoenix.LiveView
Phoenix.PubSub
Plug
Cowboy
TetWeb.*
```

### `tet_runtime_only`

Includes runtime/core/store without CLI rendering. Useful later for embedding, tests, or local-control service.

### `tet_web_local`

Includes:

```text
tet_core
tet_runtime
tet_store_sqlite or tet_store_postgres
tet_web_phoenix
```

Can run the runtime and LiveView in the same BEAM for a local UI.

### `tet_web_attached`

Runs Phoenix separately and attaches to a runtime/control service. This is not v1. It is useful after a local-control service exists.

## Dependency guard acceptance

CI must prove:

- no forbidden imports or aliases;
- no forbidden xref edges;
- no web framework in standalone release closure;
- `tet_web_phoenix` can be removed without breaking compile/tests/release;
- CLI and Phoenix call only public facade functions;
- store adapters pass shared contract tests.
