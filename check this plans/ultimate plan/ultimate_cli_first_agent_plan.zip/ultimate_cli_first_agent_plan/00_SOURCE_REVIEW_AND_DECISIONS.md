# 00 — Source Review and Final Decisions

## Sources reviewed

### 1. `agent_platform_plan_final.md`

Strengths preserved:

- explicit mode discipline;
- custom domain layer;
- runtime command/event/snapshot contract;
- formal policy/hook registry;
- categories that narrow but never widen permissions;
- typed event model;
- durable artifacts;
- provider/model registry and settings funnel;
- prompt composer, workspace rules trust, prompt debugging;
- approvals, budgets, execution targets, tool registry;
- observability, telemetry, CI/CD, secrets, auth, and deferral ledger;
- long-term roadmap for repair, remote execution, analytics, and optional Jido.

Decisions overridden:

- Do **not** begin as a Phoenix/Postgres application.
- Do **not** make Phoenix the main runtime host.
- Do **not** require Postgres in the standalone MVP.
- Do **not** build graph UI, Prompt Lab, Oban, remote work, repair, or Jido before the CLI proves the runtime.

### 2. `plan_v0.2.zip` / `plan_v0.3/`

Strengths preserved:

- final CLI-first decision;
- Tet naming to avoid conflict with Elixir's built-in `Agent` module;
- umbrella app layout that isolates Phoenix dependencies;
- public `Tet.*` facade in runtime, not core;
- dependency guards and release-closure proof;
- SQLite default store and optional Postgres adapter;
- detailed provider contract;
- durable workflow journal;
- atomic patch application and rollback;
- cancellation;
- optional Phoenix sequence;
- MCP, multi-agent, and custom-command extensions after v1.

Additions made:

- stronger source-review matrix;
- explicit LiveView control modes for same-BEAM and local-control attachment;
- more complete policy hook staging;
- clearer v1 versus v1.x boundary;
- more complete release/test/observability gates.

### 3. `tet_improved_plan.zip`

Strengths preserved:

- clean v1 product promise;
- minimal CLI command set;
- `.tet/` workspace layout;
- patch approval model;
- verifier allowlist;
- SQLite schema baseline;
- implementation module map;
- demo and acceptance scripts;
- checklists.

Additions made:

- workflow journal tables;
- trust glob model;
- policy hooks;
- LiveView optional control plan;
- extension sequencing for agents, MCP, custom slash commands, Prompt Lab, remote work, repair, analytics, and optional Jido.

## Final resolution table

| Topic | Final decision | Why |
|---|---|---|
| Product core | Standalone CLI over Elixir/OTP runtime | Satisfies headless, SSH, fast iteration, and minimal dependency goals. |
| Phoenix | Optional adapter only | Prevents web-framework gravity and keeps the CLI independently releasable. |
| Database | SQLite for standalone MVP; Postgres optional later | SQLite fits local CLI and portable `.tet/`; Postgres is valuable for team/server mode only. |
| Project shape | Umbrella repo with small apps | Enforces dependency boundaries and proves Phoenix removability. |
| Runtime | Command/event/snapshot facade plus workflow journal | Makes CLI and web peers; makes crash recovery possible. |
| CLI | First-class product, not a wrapper around Phoenix | Core value is terminal-native agent control. |
| LiveView | Controls runtime sessions through `Tet.*` or optional local-control service | It can manage CLI-created sessions without shelling out or owning state. |
| Modes | `chat`, `explore`, `execute` in v1; planning as category/profile | Keeps MVP simple while retaining planning discipline. |
| Categories | Advisory/narrowing only | Categories can restrict behavior but never grant permissions. |
| Policy | Deterministic hooks first; LLM steering later | Safety must be inspectable and testable. |
| Patch application | Diff proposal, explicit approval, atomic apply, rollback | Prevents silent writes and torn workspaces. |
| Verifiers | Named argv allowlist only | No arbitrary shell execution. |
| Agents | One built-in default profile in v1; multi-agent profiles in v1.x | Keeps v1 minimal but leaves a direct path to agent control UI. |
| MCP | v1.x extension; all MCP tools default to write until operator allowlisted | Server self-report is not trusted for safety. |
| Prompt Lab | Later advisory feature | It should never gate execution in v1. |
| Remote execution | Later execution target | Requires additional trust and credential work. |
| Oban/Jido | Deferred | Useful only after native runtime pain is proven. |

## Non-negotiable design rules

1. `tet_core` contains pure domain types, behaviours, policy contracts, codecs, IDs, and errors.
2. `tet_runtime` owns runtime supervision, public facade, workflow execution, providers, tools, event bus, redaction, and configured store dispatch.
3. `tet_cli` calls only public `Tet.*` facade functions.
4. `tet_web_phoenix` calls only public `Tet.*` facade functions or the optional local-control protocol.
5. Phoenix, LiveView, Plug, Cowboy, Phoenix.PubSub, and `TetWeb.*` are forbidden outside `tet_web_phoenix`.
6. The standalone release must prove a clean dependency closure.
7. Storage is source of truth. Process memory is never source of truth.
8. Workflow steps are journaled before side effects.
9. Blocked or modified tool attempts are persisted as first-class policy/tool events.
10. Secrets are never stored raw in domain tables, artifacts, logs, or UI payloads.
