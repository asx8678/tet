# 06 — Policy, Safety, and Approvals

## Policy pipeline

All tool requests pass through a deterministic policy pipeline before any side effect.

Initial hooks:

```text
mode_policy
workspace_trust_policy
path_policy
category_policy
agent_profile_policy
task_policy
budget_policy
approval_policy
verifier_policy
secrets_redaction_policy
```

Hook outcomes are limited to:

```text
continue
block
modify
annotate
```

Any `block` or `modify` result creates a policy event visible to the operator.

## Hook ordering

Pre-action hooks run in descending priority. Post-action hooks run in ascending priority.

Recommended priority bands:

| Band | Purpose |
|---:|---|
| 1000 | emergency global blocks |
| 900 | mode/trust/path enforcement |
| 800 | approval and verifier enforcement |
| 700 | budget/cost limits |
| 600 | secrets/redaction |
| 500 | agent profile restrictions |
| 400 | category narrowing |
| 300 | annotations and UI hints |
| 100 | analytics and learning capture |

Only deterministic hooks exist in v1. LLM-backed steering/evaluation is a later advisory layer and must never override deterministic policy.

## Path safety

Before any path-based tool runs:

1. normalize path;
2. reject NUL bytes and illegal encodings;
3. resolve symlinks;
4. ensure path remains inside workspace root;
5. apply `.gitignore`/`.tetignore` where relevant;
6. apply trust globs;
7. reject denied paths;
8. record reason if blocked.

Trust model:

```elixir
%Tet.Workspace.Trust{
  state: :untrusted | :trusted,
  allow_globs: ["**"],
  deny_globs: []
}
```

Deny wins over allow.

Example:

```bash
tet workspace trust . \
  --allow "lib/**" --allow "test/**" \
  --deny "config/runtime.exs" --deny "priv/secrets/**"
```

## Mode policy

`chat` blocks repository tools.

`explore` allows read-only repository tools.

`execute` allows writes only through patch proposal, approval, atomic apply, and verifier allowlists.

## Approval classes

| Class | Meaning | v1 behavior |
|---|---|---|
| `auto` | Allowed without human approval | Read-only safe tools only. |
| `soft` | User-visible, may continue | Later only; not needed for writes. |
| `hard` | Must pause until human approves | All patch applications. |

In v1, all writes are hard approvals.

## Patch proposal

Patch proposal does not write files. It creates:

```text
diff artifact
patch_set row
changed-file list
before-file hashes
optional file snapshots
pending approval
approval expiration
risk summary
```

## Patch application requirements

Patch application requires:

```text
trusted workspace
execute session
active task
approved approval
approval not expired
same patch hash
same target files
same workspace/session
policy still passes
paths still inside workspace
file hashes match, unless explicit rebase policy allows changes
patch applies cleanly
```

Runtime applies patches. CLI and Phoenix never apply patches directly.

## Atomic patch algorithm

1. Parse unified diff into change records.
2. Build snapshot dossier under `.tet/artifacts/file_snapshots/<approval_id>/`.
3. Write `manifest.json` atomically.
4. Run `git apply --check`.
5. Apply with `git apply` to working tree only by default.
6. Commit patch result to workflow journal.
7. Emit `patch.applied`.
8. On failure after snapshot, run idempotent rollback.

Default is working-tree apply. `git apply --index` is opt-in only.

## Rollback actions

| Original change | Rollback action |
|---|---|
| create | remove created file if present |
| delete | restore snapshot |
| modify | overwrite with snapshot |
| rename | remove post-rename path and restore pre-rename path |
| mode change | restore previous mode |

Rollback is idempotent.

## Verifier policy

Verifiers are named argv arrays from `.tet/config.toml`.

No raw shell strings.

Example:

```toml
[verification.allowlist.mix_test]
argv = ["mix", "test"]
timeout_ms = 120000
stdout_cap_bytes = 200000
stderr_cap_bytes = 200000
block_on_failure = true

[verification.allowlist.mix_format]
argv = ["mix", "format", "--check-formatted"]
timeout_ms = 60000
block_on_failure = true
```

Verifier output is saved as artifacts and redacted before display.

## Secrets and redaction

Sources, in precedence order:

1. explicit runtime environment variables;
2. OS keychain or encrypted operator config;
3. workspace `.tet/config.toml` references to secret names only;
4. built-in defaults for non-secret settings.

Rules:

- never store raw secrets in domain tables;
- never show raw secrets in CLI or LiveView;
- never save raw provider request artifacts unless redacted;
- redact secrets before provider calls;
- redaction metadata is saved without exposing values;
- `tet doctor` checks missing or unsafe secret configuration.

## Budget policy

v1 can start simple:

```text
max provider attempts per prompt
max context bytes
max output tokens
max verifier runtime
max tool timeout
```

Later budgets:

```text
session cost budget
workspace daily budget
operator budget
model fallback budget
remote execution budget
```

Budget blocks are policy events.

## Blocked attempts

A blocked attempt is not invisible. It records:

```text
tool name
args hash and safe summary
mode
category
agent profile
policy hook that blocked
reason atom
human explanation
created_at
```

This makes safety behavior inspectable in CLI and LiveView.
