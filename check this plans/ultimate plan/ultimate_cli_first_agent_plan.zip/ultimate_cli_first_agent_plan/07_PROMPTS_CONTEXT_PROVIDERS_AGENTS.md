# 07 — Prompts, Context, Providers, and Agents

## Prompt composition

Prompt layers, in order:

```text
built-in base prompt
workspace AGENT.md
workspace .tet/prompts/system.md
mode prompt
policy constraints
tool cards
agent profile prompt
workspace summary
selected context
conversation window
user message
```

Every layer should have:

```text
source
hash
included?/skipped? reason
redaction status
```

`tet prompt debug SESSION_ID --save` writes a prompt-debug artifact.

## Workspace rules trust

Workspace-provided prompt files are inert text. They cannot change tools, modes, policy, trust, approvals, budgets, or verifiers.

First use of workspace rules should create an operator-visible trust prompt or event.

Suggested files:

```text
AGENT.md
.tet/prompts/system.md
.tet/prompts/mode_chat.md
.tet/prompts/mode_explore.md
.tet/prompts/mode_execute.md
.tet/prompts/policy.md
.tet/prompts/tool_cards.md
```

## Context builder

Repository context is selected by rules, not by blindly reading the tree.

Default rules:

- respect `.gitignore`;
- respect `.tetignore`;
- never traverse `.git/`;
- hide `.tet/` internals except safe metadata needed by `doctor` and `workspace info`;
- skip binary files;
- skip dependency/build/cache folders by default;
- cap file size and total context bytes;
- redact secrets before provider calls;
- record context snapshot artifacts.

## Provider behaviour

Provider behaviour lives in `tet_core`.

```elixir
defmodule Tet.LLM.Provider do
  @callback stream(request :: map(), config :: map()) ::
    {:ok, Enumerable.t()} | {:error, term()}
end
```

Normalized stream events:

```text
started
text_delta
tool_call_delta
tool_call_done
usage
done
error
```

All provider adapters translate their wire format to this normalized stream.

## v1 provider adapters

Ship:

```text
Tet.LLM.Providers.OpenAICompatible
```

Optionally ship:

```text
Tet.LLM.Providers.Anthropic
```

Keep additional providers out of v1 unless they are trivial.

## Provider call records

Every provider call persists:

```text
provider name
model id
request id / idempotency key
prompt hash
prompt-debug artifact id
context snapshot id
input token estimate/count
output token count
latency
finish reason
cost estimate if available
redaction metadata
raw request artifact id, optional and redacted
raw response artifact id, optional and redacted
error details
```

Provider failures create events and error records.

## Model registry

Use a local JSON/TOML model registry in v1.

Suggested fields:

```json
{
  "provider": "openai_compatible",
  "model": "example-model",
  "base_url_secret": "OPENAI_BASE_URL",
  "api_key_secret": "OPENAI_API_KEY",
  "supports_streaming": true,
  "supports_tool_calls": true,
  "context_window": 128000,
  "default_max_tokens": 4096
}
```

Do not make an external model registry mandatory in v1.

## Agent model

In v1, ship one built-in default agent profile:

```text
code-default
```

It is a profile, not a new runtime type. It can restrict prompt, tools, model, and defaults, but it cannot expand permissions.

v1.x adds a profile registry.

Profile schema:

```json
{
  "name": "reviewer",
  "display_name": "Reviewer",
  "description": "Read-only code review profile",
  "system_prompt": ["Review code carefully and propose feedback."],
  "tools": ["list_dir", "read_file", "search_text", "git_status", "git_diff"],
  "default_mode": "explore",
  "default_model": null,
  "tools_config": {
    "read_file": {"timeout_ms": 5000}
  }
}
```

Profiles live in:

```text
priv/agents/                  built-ins
~/.config/tet/agents/         user profiles
<workspace>/.tet/agents/      workspace profiles, highest priority
```

Agent profile policy is narrowing only:

```text
allowed_tools = mode_allowed_tools ∩ profile_allowed_tools
```

## Multi-agent roadmap

After CLI v1:

1. add `Tet.Agent.Profile` validation in core;
2. add `Tet.Agent.Registry` in runtime;
3. add `tet agents list/show`;
4. add `tet session new --agent NAME`;
5. add `/agent NAME` interactive switch;
6. add LiveView agent profile selector;
7. add profile-specific event annotations;
8. add tests proving profiles cannot widen mode permissions.

## Custom slash commands

v1.x can discover markdown commands from:

```text
<workspace>/.tet/commands/<name>.md
<workspace>/.claude/commands/<name>.md
<workspace>/.github/prompts/<name>.md
~/.config/tet/commands/<name>.md
```

Use EEx templating, not a custom syntax.

Slash commands are inert prompt templates. They do not change policy.

## MCP roadmap

MCP is v1.x, not v1.

Rules:

- MCP is a tool source behind `Tet.Tool`;
- all MCP tools default to write classification;
- server self-reported `readOnlyHint` is displayed but not trusted;
- operator allowlist is required to classify any MCP tool as read-only;
- MCP credentials come from `Tet.Secrets`, not `config.toml` raw values;
- MCP calls are recorded as tool runs and workflow steps.

Example config:

```toml
[mcp.servers.puppeteer]
transport = "stdio"
command = "npx"
args = ["@modelcontextprotocol/server-puppeteer"]
auto_start = false

[mcp.readonly_tools]
"puppeteer:screenshot" = true
```

## Prompt Lab roadmap

Prompt Lab is advisory and later.

It can compare prompts, inspect prompt-debug artifacts, and suggest improvements. It must not gate execution, approve writes, or bypass policy.
