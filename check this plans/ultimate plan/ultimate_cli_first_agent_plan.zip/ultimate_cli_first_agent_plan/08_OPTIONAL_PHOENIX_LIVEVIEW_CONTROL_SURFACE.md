# 08 — Optional Phoenix LiveView Control Surface

## Core rule

Phoenix LiveView is an optional adapter over Tet. It is not the runtime.

```text
LiveView controls Tet sessions and agents through Tet.*.
LiveView does not control files, patches, providers, verifiers, or approvals directly.
```

## Why LiveView is still useful

The CLI is the core, but a browser UI is better for:

- diff review;
- approval queues;
- artifact browsing;
- event timelines;
- provider/model status;
- budget/cost display;
- graph inspection;
- multi-agent profile management;
- remote coordination later.

## When to build it

Only after CLI v1 acceptance passes.

The first LiveView release must be smaller than the CLI:

```text
session list
session page
event stream
diff approval/rejection
verifier trigger
artifact browser
cancel button
```

No Prompt Lab, graph canvas, remote execution, team auth, or analytics in the first web adapter.

## Two optional control modes

### Mode A — embedded local web release

`tet_web_local` starts Phoenix and Tet runtime in the same BEAM.

```text
browser -> LiveView -> Tet.* -> runtime -> SQLite/Postgres
CLI     -> Tet.*    -> runtime/store as normal
```

Use this first because it is simplest.

### Mode B — attached local-control service

Post-v1, `tet control start` may run a local runtime service over a Unix socket or named pipe.

```text
CLI      -> Tet.Control.Client -> local runtime service -> Tet.*
LiveView -> Tet.Control.Client -> local runtime service -> Tet.*
```

This lets CLI and LiveView control the same long-running agents without Phoenix owning the runtime.

Security defaults:

- loopback/socket only;
- owner-only file permissions;
- random token;
- no remote bind by default;
- same policy pipeline;
- all commands audited as actor `local_operator` until auth is added.

## What LiveView may do

Allowed operations:

```text
Tet.start_session
Tet.send_prompt
Tet.list_events
Tet.subscribe
Tet.list_approvals
Tet.approve_patch
Tet.reject_patch
Tet.run_verification
Tet.cancel
Tet.prompt_debug
Tet.get_artifact
Tet.status
Tet.explain
```

LiveView pages:

```text
/dashboard
/workspaces/:id
/sessions/:id
/approvals
/artifacts/:id
/settings/models
/settings/agents      # after agent profiles
/settings/tools       # read-only initially
```

## What LiveView must not do

Forbidden:

- direct database mutations;
- direct patch apply;
- direct file writes;
- direct verifier execution;
- direct provider calls;
- direct secrets access;
- shelling out to `tet` for normal operations;
- bypassing policy by calling lower-level modules;
- introducing Phoenix dependencies into `tet_core`, `tet_runtime`, `tet_cli`, or store apps.

## First LiveView session page

Suggested layout:

```text
Top bar:
  workspace, session, mode, category, provider/model, status, cost summary

Left rail:
  session list, approval queue, artifacts

Center:
  message stream and event timeline

Right drawer:
  selected event/tool/provider/approval/artifact inspector

Bottom/action area:
  prompt box, cancel button, verifier picker, approval actions
```

## Approval UI requirements

The approval UI must show:

- patch id and approval id;
- changed files;
- unified diff;
- risk summary;
- policy annotations;
- before-file hashes;
- verifier recommendations if any;
- approve and reject actions;
- expiration status;
- rollback status after apply.

Approve/reject buttons call only `Tet.approve_patch/2` and `Tet.reject_patch/2`.

## Event streaming

Embedded mode can use the runtime's event bus directly through `Tet.subscribe/2`.

Attached mode uses the local-control protocol to stream events.

LiveView must dedupe events by event id and tolerate reconnect/replay.

## Auth stance

First local web adapter:

- loopback-only by default;
- generated local session token;
- no public network bind unless operator explicitly configures it;
- actor id defaults to `local_operator`;
- every approval records actor id and source surface (`cli` or `web`).

Team auth and SSO are later and require Postgres/team mode.

## Phoenix acceptance checklist

The optional web adapter is accepted only when:

- standalone release still contains no Phoenix closure;
- `apps/tet_web_phoenix` can be deleted and standalone compile/test/release still pass;
- LiveView calls only `Tet.*` or local-control client;
- approvals through LiveView produce the same events as approvals through CLI;
- cancellation through LiveView uses `Tet.cancel/3`;
- web event timeline matches `tet events tail` for the same session;
- secrets are redacted in all rendered views;
- no direct DB writes appear in LiveView modules.
