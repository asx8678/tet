# 11 — Risks and Deferrals

## Top risks

| Risk | Impact | Mitigation |
|---|---|---|
| Phoenix gravity pulls runtime into web app | CLI stops being standalone | Hard dependency guards, release closure proof, web-removability test. |
| SQLite concurrency surprises | Broken approvals or event sequence collisions | Single-writer discipline, transactions, locks, contract tests, clear local-control model. |
| Provider streaming edge cases | Lost messages or duplicate tool calls | Normalized stream events, workflow journal, idempotency keys, replay tests. |
| Patch application tears workspace | User loses trust | Snapshot dossier, `git apply --check`, atomic workflow step, idempotent rollback, crash tests. |
| Policy bypass through UI | Unsafe writes | UI calls only facade; policy pipeline is inside runtime; tests scan for forbidden calls. |
| Secrets leak into artifacts/logs | High severity privacy/security failure | Redaction before persistence/display, tests with canary secrets, no raw secrets in DB. |
| Scope creep delays v1 | No usable product | Strict non-goals and phase gates. |
| MCP tool trust is overestimated | Malicious third-party tool bypasses safety | MCP tools default to write; operator allowlist required for read-only classification. |
| Agent profiles become permission grants | Policy confusion | Profiles narrow only; tests prove no widening. |
| Remote execution changes trust boundary | Credential and filesystem risk | Defer until local CLI is stable; explicit target trust/credential model. |

## Deliberate deferrals

### Phoenix LiveView

Deferred until CLI v1 acceptance. Reason: it is optional and must not shape the core runtime.

### Postgres

Deferred until team/server mode. Reason: SQLite is enough for local standalone and easier to distribute.

### Local-control daemon/service

Deferred until after optional UI or long-running workflows need it. Reason: one-shot CLI and approval pause can work without a daemon.

### MCP

Deferred to v1.x. Reason: adds third-party tool trust and transport complexity.

### Multi-agent profiles

Basic default profile exists in v1. Full registry deferred to v1.x.

### Prompt Lab

Deferred. It is advisory and should not block runtime safety.

### Remote execution

Deferred. Requires host-key verification, credential handling, remote artifacts, and privilege boundaries.

### Repair/nano-repair

Deferred. Depends on error records, verifier results, and stable patch workflow.

### Bronze/Silver/Gold analytics

Deferred. Raw typed records and events must exist first.

### Oban

Deferred until durable background jobs are needed beyond local workflow journal.

### Jido

Deferred. Allowed only as a runtime backend pilot if native OTP runtime pain is proven.

Forbidden Jido scope:

- prompt ownership;
- task/mode/approval policy ownership;
- artifacts/plans/errors as source of truth;
- provider routing;
- secrets;
- maintenance analytics.

## Kill criteria for optional features

Do not add a feature if it:

- adds Phoenix dependency to standalone release;
- bypasses `Tet.*`;
- requires Postgres for local CLI;
- weakens patch approval;
- stores raw secrets;
- creates unreviewable tool execution;
- makes recovery nondeterministic;
- cannot be tested by contract tests;
- cannot be removed without breaking v1 CLI.
