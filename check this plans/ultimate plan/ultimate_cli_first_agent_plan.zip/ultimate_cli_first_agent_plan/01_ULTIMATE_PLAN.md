# 01 — Ultimate Plan

## Executive decision

Build **Tet** as a standalone Elixir/OTP coding-agent runtime with the **CLI as the core product**. Phoenix LiveView is an optional interface that can control the same sessions, agents, approvals, artifacts, and event timelines through the public runtime boundary.

```text
Core:      Elixir/OTP runtime + CLI + SQLite + .tet workspace state
Optional:  Phoenix LiveView adapter + same runtime + same public API
Later:     Postgres/team mode, MCP, multi-agent profiles, remote execution, repair, analytics, Jido/Oban if justified
```

The minimum useful product is not a web app. It is a safe local CLI agent that can talk, inspect, propose patches, pause for approval, apply approved diffs, run named verifiers, and preserve an auditable timeline.

## Product promise for v1

Tet v1 can:

1. initialize a local repository workspace;
2. create sessions in `chat`, `explore`, or `execute` mode;
3. chat without repository access;
4. inspect repository files in read-only mode;
5. build bounded/redacted context snapshots;
6. call one configured provider/model through the normalized provider contract;
7. propose unified-diff patches in execute mode;
8. require explicit approval before applying patches;
9. apply only approved, still-valid patches;
10. rollback torn or failed patch applications;
11. run only named allowlisted verifiers;
12. persist sessions, tasks, messages, tool runs, approvals, artifacts, provider calls, verifier runs, context snapshots, workflow steps, and events;
13. expose timelines through CLI commands and event streams;
14. produce a standalone release with no web-framework dependency closure.

## MVP non-goals

Do not build these before the standalone CLI passes acceptance:

- Phoenix LiveView UI;
- `tet web` command;
- daemon/control service;
- TUI;
- Prompt Lab;
- multi-node runtime;
- remote execution;
- Oban;
- Jido;
- autonomous planner/executor orchestration;
- MCP client;
- multi-agent profile registry beyond one built-in default;
- Bronze/Silver/Gold analytics;
- repair/nano-repair mode;
- team auth or SSO;
- Postgres mainline.

These are planned, but they must not block the minimal CLI.

## Final system shape

```text
tet_umbrella/
  mix.exs
  config/
  tools/
  apps/
    tet_core/             # pure domain structs, commands, events, policies, behaviours, codecs
    tet_runtime/          # OTP runtime, public Tet facade, workflows, event bus, tools, providers
    tet_cli/              # standalone terminal product
    tet_store_memory/     # fast tests and contract tests
    tet_store_sqlite/     # default local standalone store
    tet_store_postgres/   # optional future team/server store
    tet_web_phoenix/      # optional LiveView adapter, post-v1
```

Only these apps are required for v1:

```text
tet_core
tet_runtime
tet_cli
tet_store_memory
tet_store_sqlite
```

Create `tet_store_postgres` and `tet_web_phoenix` only as postponed contracts or empty stubs until the CLI is accepted.

## Core runtime principle

The CLI is not the runtime. Phoenix is not the runtime. Both are user interfaces over the same runtime boundary.

```text
operator input
  -> CLI or LiveView
  -> public Tet.* facade
  -> command validation
  -> policy pipeline
  -> workflow journal
  -> side effect
  -> durable events/artifacts
  -> CLI/LiveView projections
```

## Public facade principle

All user-facing adapters call `Tet.*` from `tet_runtime`.

They may pattern-match on pure structs from `tet_core` such as `%Tet.Event{}`, `%Tet.Session{}`, `%Tet.Approval{}`, and `%Tet.Artifact{}`.

They must not call runtime internals such as `Tet.Runtime.*`, `Tet.Store.*`, `Tet.Tools.*`, `Tet.EventBus.*`, or provider internals.

## Minimal v1 mode model

| Capability | `chat` | `explore` | `execute` |
|---|:---:|:---:|:---:|
| Provider response | yes | yes | yes |
| Message persistence | yes | yes | yes |
| Event timeline | yes | yes | yes |
| Repository read tools | no | yes | yes |
| Patch proposal | no | no | yes |
| Patch application | no | no | approved only |
| Verification command | no | no | allowlisted only |
| Arbitrary shell | no | no | no |

Planning is a category/profile in v1, not a separate security mode. A planning profile can produce structured plans but cannot widen tool permissions. If it needs repository inspection, run it in `explore` mode with `category=planning`. If it does not, run it in `chat` mode.

## Categories

Categories are labels and policy narrowers. They never widen behavior.

Initial categories:

- `planning` — no writes; can create plan artifacts only.
- `implementation` — normal execute path.
- `review` — read/diff/test oriented; no writes by default.
- `verification` — verifier-focused; no patch creation.
- `repair` — diagnostic-first; mutating repair requires explicit escalation.

Rule:

```text
allowed = mode_policy ∩ task_policy ∩ category_policy ∩ agent_profile_policy ∩ budget_policy ∩ approval_policy
```

No category can turn a forbidden action into an allowed action.

## Storage stance

Standalone v1 uses workspace-local SQLite:

```text
repo-root/.tet/
  tet.sqlite
  config.toml
  prompts/
  artifacts/
  cache/
  locks/
```

Postgres is an optional adapter for server/team mode. It must implement the same store behaviour and pass the same contract tests.

## Safety stance

Write operations use this flow:

```text
agent proposes unified diff
  -> policy validates mode, trust, path, task, budget, and pending-approval rules
  -> diff artifact is content-addressed and saved
  -> patch_set row is created
  -> pending approval is created
  -> CLI or LiveView shows the diff and risk summary
  -> user approves or rejects through Tet.*
  -> workflow resumes
  -> runtime applies approved patch only if it still applies cleanly
  -> rollback is available and crash recovery is deterministic
  -> named verifier may run
  -> all events, tool runs, artifacts, verifier output, and policy decisions are persisted
```

Blocked tool intents are persisted as blocked tool runs and policy events with reason atoms. They are visible in timelines.

## Provider stance

v1 ships one or two provider adapters:

```text
Tet.LLM.Providers.OpenAICompatible
Tet.LLM.Providers.Anthropic optional if time permits
```

All providers implement one normalized streaming behaviour. Provider failures become events and error records, not process crashes.

## Prompt stance

Prompt composition is layered and inspectable:

```text
built-in base prompt
workspace AGENT.md
workspace .tet/prompts/system.md
mode prompt
policy constraints
tool cards
agent profile prompt
workspace summary
selected context
conversation window
user message
```

Every provider call may save a redacted prompt-debug artifact that explains the layers, hashes, context selection, and redactions.

## LiveView stance

Phoenix LiveView is optional after CLI v1. It can:

- list workspaces and sessions;
- start sessions;
- send prompts;
- stream events;
- show active model/provider;
- show tool runs and policy blocks;
- show diffs and approve/reject patches;
- trigger named verifiers;
- browse artifacts;
- manage agent profiles after multi-agent support lands;
- stop/cancel workflows.

It cannot:

- apply patches directly;
- bypass approvals;
- bypass mode, trust, category, budget, or verifier policy;
- own storage;
- own provider calls;
- own secrets;
- introduce Phoenix dependencies into the standalone release;
- shell out to `tet` for normal operations.

## Build order

1. Freeze decisions and create repo skeleton.
2. Implement domain structs, IDs, codecs, errors, commands, events, policy contracts.
3. Implement policy tests, path tests, trust tests, and approval state-machine tests.
4. Implement store behaviour, memory store, and contract tests.
5. Implement SQLite store, migrations, `.tet/` init, artifact writer, and config loader.
6. Implement runtime supervision, public `Tet` facade, workflow journal, event bus, and cancellation.
7. Implement CLI foundation, JSON mode, exit codes, `doctor`, `init`, `workspace`, `session`, and timeline commands.
8. Implement provider behaviour, prompt composer, prompt debug, and chat mode.
9. Implement context builder, `.tetignore`, read tools, and explore mode.
10. Implement patch proposal, approval lifecycle, snapshot dossier, expiration, atomic apply, and rollback.
11. Implement verifier allowlist, verifier artifacts, output caps, and redaction.
12. Implement end-to-end demo, acceptance runner, release closure proof, and standalone release.
13. Only then implement optional Phoenix LiveView adapter.
14. Then add local-control service, multi-agent profiles, custom slash commands, MCP, Prompt Lab, remote execution, repair, analytics, Postgres/team mode, and optional Jido/Oban as justified.

## Final v1 success condition

Tet v1 is accepted when this works in a real repository:

```bash
tet init . --trust
tet doctor
S_CHAT=$(tet session new . --mode chat --json | jq -r '.data.session.short_id')
tet ask "$S_CHAT" "what does this repo do?" --json
S_EXPLORE=$(tet session new . --mode explore --json | jq -r '.data.session.short_id')
tet explore "$S_EXPLORE" "find the main entrypoint" --json
S_EXEC=$(tet session new . --mode execute --json | jq -r '.data.session.short_id')
tet edit "$S_EXEC" "add a short README note" --json
APPROVAL_ID=$(tet approvals "$S_EXEC" --json | jq -r '.data.approvals[0].short_id')
tet patch approve "$APPROVAL_ID"
tet verify "$S_EXEC" mix_test --json
tet status "$S_EXEC" --json
```

And this proves standalone release isolation:

```bash
MIX_ENV=prod mix release tet_standalone --overwrite
_build/prod/rel/tet_standalone/bin/tet doctor
tools/check_release_closure.sh
```

The release closure must contain no Phoenix, Phoenix.LiveView, Phoenix.PubSub, Plug, Cowboy, or `TetWeb.*` modules.
