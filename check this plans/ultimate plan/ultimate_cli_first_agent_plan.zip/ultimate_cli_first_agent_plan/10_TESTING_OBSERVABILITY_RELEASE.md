# 10 — Testing, Observability, and Release

## Test pyramid

### Unit tests

- domain structs;
- codecs;
- ID generation;
- policy decisions;
- approval state machine;
- prompt composition;
- provider stream normalization;
- patch parser;
- redaction.

### Contract tests

- store behaviour for memory and SQLite;
- provider behaviour with fake provider;
- tool behaviour;
- verifier behaviour;
- public `Tet.*` facade.

### Integration tests

- workspace init;
- chat provider call with fake provider;
- explore read tools;
- patch proposal;
- approval apply/reject;
- verifier run;
- cancellation;
- workflow recovery.

### Property tests

- codec round trips;
- path resolver rejects escapes;
- deny globs always beat allow globs;
- approval state machine legal transitions;
- idempotency key stability;
- workflow replay determinism;
- apply+rollback restores workspace hash;
- short-id collision threshold.

### Fuzz tests

- path resolver with `..`, symlinks, NUL bytes, encoded separators, Windows separators, long components, and case variants;
- malformed unified diffs;
- provider stream chunks split at arbitrary byte boundaries;
- JSON tool-call argument fragments.

### CLI smoke tests

- every v1 command has `--json` test;
- exit codes are tested;
- human rendering does not leak secrets;
- `tet edit` returns `3` while waiting for approval.

### LiveView tests after optional UI

- session page renders from `Tet.status`/snapshot;
- approval click calls facade;
- event reconnect dedupes;
- no direct store calls;
- secret redaction.

## Observability baseline

Use structured logs and telemetry from v1.

Telemetry examples:

```text
[:tet, :runtime, :command, :start]
[:tet, :runtime, :command, :stop]
[:tet, :workflow, :step, :start]
[:tet, :workflow, :step, :stop]
[:tet, :provider, :call, :start]
[:tet, :provider, :call, :stop]
[:tet, :tool, :run, :start]
[:tet, :tool, :run, :stop]
[:tet, :approval, :created]
[:tet, :patch, :applied]
[:tet, :verifier, :finished]
[:tet, :policy, :blocked]
```

Every telemetry/log payload must pass redaction.

## Logs

Structured log fields:

```text
workspace_id
session_id
workflow_id
step_name
command
surface: cli|web|control
actor_id
provider
model
tool_name
approval_id
patch_set_id
event_id
error_code
duration_ms
```

## CI pipeline

Required jobs:

```text
format
compile --warnings-as-errors
unit tests
contract tests
integration tests
property/fuzz tests where feasible
source guard
xref guard
standalone release closure
CLI smoke
```

After optional Phoenix:

```text
LiveView tests
web-removability test
web no-direct-store test
```

## Release closure proof

`tools/check_release_closure.sh` must fail if these appear in `tet_standalone`:

```text
phoenix
phoenix_live_view
phoenix_pubsub
plug
cowboy
phoenix_html
TetWeb.*
```

## Release profiles

```text
tet_standalone     core + runtime + cli + sqlite + provider
tet_runtime_only   core + runtime + store, no CLI/web
tet_web_local      core + runtime + store + phoenix app
tet_web_attached   phoenix app + control client, later
```

## Versioning

Use semantic versions for releases.

Event/schema changes require:

- migration;
- event version bump if payload shape changes;
- compatibility note;
- CLI JSON schema note;
- rollback or backup instructions.

## Release checklist

Before tagging:

- acceptance runner passes;
- demo script passes in a fixture repo;
- no forbidden dependencies in standalone release;
- docs updated;
- schema migration checked;
- redaction tests pass;
- provider tests pass;
- patch rollback tests pass;
- all v1 commands tested in `--json` mode;
- release archive generated;
- changelog written.
