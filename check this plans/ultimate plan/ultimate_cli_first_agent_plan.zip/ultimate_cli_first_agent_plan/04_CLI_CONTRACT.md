# 04 — CLI Contract

## CLI identity

`tet` is the default product. It must work without Phoenix, Postgres, daemon mode, or remote services.

## Required v1 commands

```text
tet doctor [PATH] [--json]
tet init [PATH] [--trust] [--copy-default-prompts] [--json]
tet workspace trust PATH [--allow GLOB] [--deny GLOB] [--json]
tet workspace untrust PATH [--json]
tet workspace info [PATH] [--json]

tet session new PATH [--mode chat|explore|execute] [--provider NAME] [--model ID] [--category NAME] [--json]
tet session list [PATH] [--json]
tet session show SESSION_ID [--json]

tet chat SESSION_ID
tet ask SESSION_ID "question" [--json]
tet explore SESSION_ID "inspect this" [--json]
tet edit SESSION_ID "make this change" [--json]

tet approvals SESSION_ID [--json]
tet patch approve APPROVAL_ID [--json]
tet patch reject APPROVAL_ID [--json]
tet patch rollback PATCH_ID [--json]

tet verify SESSION_ID VERIFIER_NAME [--json]
tet status SESSION_ID [--json]
tet explain SESSION_ID [--json]
tet prompt debug SESSION_ID [--save] [--json]
tet events tail SESSION_ID [--json]
tet cancel SESSION_ID [--force] [--json]
```

## Explicitly not v1

```text
tet web
tet daemon
tet serve
tet tui
tet prompt lab
tet run autonomous
tet repair
tet remote
tet worker
tet mcp
tet migrate beyond schema checks
tet memory
tet team
tet auth
```

These may arrive later through phase gates.

## Modes and tool access

| Tool/capability | Chat | Explore | Execute |
|---|:---:|:---:|:---:|
| Provider response | allow | allow | allow |
| Message persistence | allow | allow | allow |
| Event timeline | allow | allow | allow |
| `list_dir` | block | allow | allow |
| `read_file` | block | allow | allow |
| `search_text` | block | allow | allow |
| `git_status` | block | allow | allow |
| `git_diff` | block | allow | allow |
| `propose_patch` | block | block | allow -> pending approval |
| `apply_approved_patch` | block | block | approved only |
| `run_verifier` | block | block | named allowlist only |
| arbitrary shell | block | block | block |

## JSON output contract

Every `--json` command returns one JSON object:

```json
{
  "ok": true,
  "data": {},
  "events": [],
  "warnings": [],
  "meta": {
    "schema_version": 1,
    "command": "session.new",
    "duration_ms": 42
  }
}
```

Errors:

```json
{
  "ok": false,
  "error": {
    "code": "path_denied_by_trust",
    "message": "Writes to config/runtime.exs are denied by workspace trust policy.",
    "category": "policy",
    "remediation": "Adjust workspace trust globs only if you intend to allow this path."
  },
  "events": [],
  "warnings": [],
  "meta": {
    "schema_version": 1,
    "command": "edit"
  }
}
```

## Exit codes

| Code | Meaning |
|---:|---|
| 0 | success |
| 1 | general failure |
| 2 | usage/argument error |
| 3 | waiting for approval |
| 4 | policy denied |
| 5 | provider failure |
| 6 | verifier failure |
| 7 | patch failed or rollback needed |
| 8 | storage/migration error |
| 9 | trust/secrets/config error |
| 10 | cancellation |

`tet edit` returns `3` when it successfully creates a pending approval and pauses.

## Interactive command loop

Inside `tet chat SESSION_ID`:

```text
/help
/status
/events
/approvals
/approve APPROVAL_ID
/reject APPROVAL_ID
/verify VERIFIER_NAME
/cancel
/prompt-debug
/agent            # v1.x after agent profiles
/agent NAME       # v1.x
/mcp status       # v1.x after MCP
```

Slash commands are UI sugar. They call `Tet.*` and never bypass policy.

## Human rendering requirements

The CLI must make these readable without a web UI:

- pending approvals;
- unified diffs;
- changed-file lists;
- policy block reasons;
- verifier output summaries;
- timeline events;
- provider/model/cost metadata when available;
- prompt-debug artifact paths;
- recovery/rollback notices.

## CLI ergonomics

- All commands accept short IDs where unambiguous.
- `tet lookup KIND SHORT_ID` can resolve ambiguity.
- `--json` never prints human decoration.
- `--quiet` suppresses nonessential output but never suppresses errors.
- `--no-color` is available.
- Interactive prompts must have noninteractive alternatives.
- Any command that could wait on provider output should support cancellation.
- Any command that writes files must print or return the approval/patch id.

## v1 demo flow

```bash
tet init . --trust
tet doctor
S_CHAT=$(tet session new . --mode chat --json | jq -r '.data.session.short_id')
tet ask "$S_CHAT" "what does this repo do?" --json
S_EXPLORE=$(tet session new . --mode explore --json | jq -r '.data.session.short_id')
tet explore "$S_EXPLORE" "find the main entrypoint" --json
S_EXEC=$(tet session new . --mode execute --json | jq -r '.data.session.short_id')
tet edit "$S_EXEC" "add a short README note" --json || test "$?" = 3
tet approvals "$S_EXEC"
APPROVAL_ID=$(tet approvals "$S_EXEC" --json | jq -r '.data.approvals[0].short_id')
tet patch approve "$APPROVAL_ID"
tet verify "$S_EXEC" mix_test --json
tet status "$S_EXEC" --json
```
