# Safety Acceptance Checklist

## Policy

- [ ] Mode policy blocks disallowed tool classes.
- [ ] Trust policy blocks untrusted writes.
- [ ] Path policy blocks escapes, symlinks outside workspace, denied globs, and unsafe paths.
- [ ] Category policy narrows only.
- [ ] Agent profile policy narrows only.
- [ ] Budget policy blocks over-limit provider/tool/verifier usage.
- [ ] Blocked attempts are visible in event timeline.

## Patches

- [ ] Patch proposal is side-effect free.
- [ ] Snapshot dossier is written before apply.
- [ ] `git apply --check` runs before apply.
- [ ] Rollback works for create/delete/modify/rename/mode changes.
- [ ] Crash during patch apply recovers safely.

## Secrets

- [ ] Canary secrets do not appear in logs.
- [ ] Canary secrets do not appear in artifacts.
- [ ] Canary secrets do not appear in CLI output.
- [ ] Canary secrets do not appear in LiveView output.
- [ ] Raw secrets are absent from domain tables.

## Tools and verifiers

- [ ] Raw shell strings are rejected.
- [ ] Verifiers are argv arrays only.
- [ ] Tool outputs are capped.
- [ ] Tool timeouts are enforced.
- [ ] MCP tools default to write classification after MCP lands.
