# Phoenix Optional Adapter Checklist

Build this only after CLI v1 passes.

- [ ] `tet_web_phoenix` is isolated in its own app.
- [ ] LiveView modules call only `Tet.*` or optional local-control client.
- [ ] No direct DB writes from LiveView.
- [ ] No direct patch apply from LiveView.
- [ ] No direct provider calls from LiveView.
- [ ] No direct verifier execution from LiveView.
- [ ] Approval UI calls `Tet.approve_patch/2` and `Tet.reject_patch/2`.
- [ ] Cancel button calls `Tet.cancel/3`.
- [ ] Event stream dedupes by event id.
- [ ] Web timeline matches `tet events tail`.
- [ ] Secrets are redacted in all views.
- [ ] `tet_standalone` release closure remains clean.
- [ ] Deleting `apps/tet_web_phoenix` leaves standalone compile/test/release green.
