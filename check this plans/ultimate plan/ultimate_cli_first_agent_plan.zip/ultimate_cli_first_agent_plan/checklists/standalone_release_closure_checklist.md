# Standalone Release Closure Checklist

- [ ] `apps/tet_core` has no Phoenix/Plug/Cowboy/Ecto/runtime-internal dependency leaks.
- [ ] `apps/tet_runtime` has no Phoenix/Plug/Cowboy/TetWeb dependency leaks.
- [ ] `apps/tet_cli` has no Phoenix/Plug/Cowboy/TetWeb/store-internal/runtime-internal dependency leaks.
- [ ] Store adapters have no CLI, Phoenix, or runtime-internal dependency leaks.
- [ ] `mix xref graph` has no forbidden edges.
- [ ] `tet_standalone` release excludes Phoenix libraries.
- [ ] `tet_standalone` boots without starting Phoenix/Plug/Cowboy applications.
- [ ] `Tet.doctor/2` is reachable from release.
- [ ] Removing or ignoring `apps/tet_web_phoenix` does not change standalone behavior.
