# MVP Acceptance Checklist

## Workspace and config

- [ ] `tet init . --trust` creates `.tet/` and SQLite schema.
- [ ] `tet doctor` validates schema, git, config, provider, secrets, verifier allowlist, artifact dirs, and permissions.
- [ ] `.tetignore` is respected.
- [ ] Trust globs work; deny wins over allow.

## CLI

- [ ] Every v1 command exists.
- [ ] Every v1 command with `--json` returns the documented JSON envelope.
- [ ] Exit codes match the contract.
- [ ] Human rendering is readable and redacts secrets.

## Modes

- [ ] Chat mode blocks repository tools.
- [ ] Explore mode allows read tools only.
- [ ] Execute mode creates pending approvals for writes.
- [ ] Categories narrow only and never widen permissions.

## Provider/prompt

- [ ] Provider stream is normalized.
- [ ] Provider call records are persisted.
- [ ] Prompt-debug artifact is generated and redacted.
- [ ] Context snapshot records included/skipped/truncated/redacted files.

## Patches and approvals

- [ ] Patch proposal writes no files.
- [ ] Pending approval is created with diff artifact and risk summary.
- [ ] Approval applies only matching patch hash and paths.
- [ ] Rejection does not apply files.
- [ ] Expired approval cannot apply.
- [ ] Rollback restores pre-apply workspace hash.

## Verifiers

- [ ] Only named allowlisted verifiers run.
- [ ] Raw shell strings are rejected.
- [ ] Output caps apply.
- [ ] stdout/stderr artifacts are saved and redacted.

## Durable execution

- [ ] Workflow steps are journaled before side effects.
- [ ] Crash recovery handles provider call, patch apply, rollback, and verifier cases.
- [ ] Approval pause survives restart.
- [ ] Cancellation creates durable events.

## Standalone release

- [ ] `MIX_ENV=prod mix release tet_standalone --overwrite` succeeds.
- [ ] `_build/prod/rel/tet_standalone/bin/tet doctor` succeeds.
- [ ] Release closure contains no Phoenix, LiveView, Plug, Cowboy, Phoenix.PubSub, or `TetWeb.*`.
