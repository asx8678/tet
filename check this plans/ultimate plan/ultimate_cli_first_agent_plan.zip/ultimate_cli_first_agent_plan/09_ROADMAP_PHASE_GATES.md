# 09 — Roadmap and Phase Gates

## Phase 0 — Freeze decisions and skeleton

Build:

- umbrella repo;
- app skeletons;
- dependency guards;
- initial ADRs;
- CI for compile/test/guards;
- no Phoenix generated yet unless isolated stub only.

Done means:

- `mix compile` passes;
- forbidden reference guard passes;
- release profile plan exists;
- source-review decisions accepted.

## Phase 1 — Core domain and policy contracts

Build:

- domain structs;
- command structs;
- event structs;
- error model;
- ID/short-ID generation;
- `Tet.Codec`;
- policy hook behaviour;
- provider/tool/store behaviours;
- approval state machine;
- patch types.

Done means:

- unit tests pass;
- codec round-trip tests pass;
- no IO in core;
- core has no forbidden dependencies.

## Phase 2 — Store contracts and SQLite

Build:

- `Tet.Store` behaviour;
- memory store;
- SQLite migrations;
- contract tests;
- `.tet/` init;
- artifact writer;
- schema version checks.

Done means:

- memory and SQLite stores pass identical contract tests;
- `tet init` can create `.tet/`;
- `tet doctor` detects schema/config errors.

## Phase 3 — Runtime facade and workflow journal

Build:

- `Tet.*` facade;
- runtime supervision;
- command dispatch;
- event bus;
- workflow and workflow_step records;
- idempotency keys;
- recovery scan;
- cancellation.

Done means:

- commands create events;
- workflow steps journal before effects;
- cancellation creates durable event;
- runtime can boot without CLI/Phoenix.

## Phase 4 — CLI foundation

Build:

- `tet` entrypoint;
- argument parsing;
- JSON output;
- exit codes;
- human rendering;
- commands: `doctor`, `init`, `workspace`, `session`, `status`, `events tail`.

Done means:

- CLI commands call only `Tet.*`;
- JSON contract tests pass;
- exit code tests pass.

## Phase 5 — Chat mode and providers

Build:

- provider behaviour implementation;
- model registry;
- secrets resolver;
- prompt composer;
- prompt-debug artifacts;
- chat mode;
- provider event streaming;
- provider failure events.

Done means:

- `tet ask` works in chat mode;
- provider call records are persisted;
- prompt debug works;
- secrets are redacted.

## Phase 6 — Explore mode and read tools

Build:

- context builder;
- `.tetignore`;
- read tools: `list_dir`, `read_file`, `search_text`, `git_status`, `git_diff`;
- path policy;
- context snapshots.

Done means:

- `tet explore` can inspect a repo;
- blocked chat-mode read attempts are recorded;
- path fuzz tests pass.

## Phase 7 — Execute mode, approvals, patches

Build:

- `propose_patch` tool;
- diff artifact;
- patch_set;
- approval lifecycle;
- approval expiration;
- atomic apply;
- rollback;
- dirty workspace policy.

Done means:

- `tet edit` pauses with approval;
- `tet patch approve` applies only approved patches;
- rollback tests pass;
- crash recovery tests pass.

## Phase 8 — Verification

Build:

- verifier allowlist parser;
- verifier runner;
- output caps;
- stdout/stderr artifacts;
- verifier events;
- `tet verify`.

Done means:

- named verifiers run;
- raw shell strings are rejected;
- verifier failures are clear.

## Phase 9 — Standalone hardening and release

Build:

- acceptance runner;
- demo script;
- release profile;
- release closure proof;
- source/xref guards;
- telemetry/log baseline;
- docs/checklists.

Done means:

- `tet_standalone` release works;
- no Phoenix closure;
- end-to-end demo passes.

## Phase 10 — Optional LiveView adapter

Build:

- isolated `tet_web_phoenix` app;
- dashboard;
- session page;
- event stream;
- approval UI;
- artifact browser;
- verifier trigger;
- cancel button.

Done means:

- web calls only `Tet.*`;
- deleting web app does not break standalone;
- web approvals match CLI approvals.

## Phase 11 — Local-control service

Build:

- loopback Unix socket/named pipe service;
- token-based local auth;
- CLI control client;
- LiveView attach mode;
- event streaming over control protocol.

Done means:

- CLI and LiveView can attach to the same long-running runtime;
- service remains optional;
- policies and audit actor/source still apply.

## Phase 12 — v1.x extensions

Build only after the previous gates:

- multi-agent profile registry;
- custom slash commands;
- MCP client;
- Prompt Lab advisory mode;
- Postgres/team adapter;
- remote execution targets;
- planner/executor split;
- repair and nano-repair;
- Bronze/Silver/Gold analytics;
- optional Oban/Jido pilot.

Each extension must have its own acceptance gate and must not weaken the standalone CLI.
