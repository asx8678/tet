# Ultimate CLI-First Agent Platform Plan

Generated: 2026-04-29

This package consolidates the uploaded plans into one final build plan for a minimal standalone CLI agent platform with Phoenix LiveView as an optional control surface.

## Final decision

Build **Tet** as a standalone Elixir/OTP runtime with a CLI-first product surface.

Phoenix LiveView is optional. It may inspect, control, and approve work through the same public runtime API used by the CLI, but it must never own runtime state, policies, storage, providers, patching, verification, approvals, secrets, or artifacts.

```text
Tet must run through Elixir/OTP, not through Phoenix.
The CLI is the default product.
Phoenix is an optional adapter over the same runtime.
```

## What changed from the uploaded plans

The uploaded plans contain one major conflict:

- `agent_platform_plan_final.md` is strong on governance, hooks, events, observability, auth, secrets, testing, and long-term operator-console design, but it is Phoenix/Postgres-first.
- `plan_v0.2.zip` actually contains `plan_v0.3/`, which is already close to the desired CLI-first architecture.
- `tet_improved_plan.zip` has the cleanest MVP boundary, SQLite defaults, CLI contract, checklists, and implementation sketches.

This package resolves the conflict by making the standalone CLI the core and preserving the strongest safety, runtime, provider, telemetry, and release discipline from all plans.

## Suggested reading order

1. `00_SOURCE_REVIEW_AND_DECISIONS.md`
2. `01_ULTIMATE_PLAN.md`
3. `02_ARCHITECTURE_AND_BOUNDARIES.md`
4. `04_CLI_CONTRACT.md`
5. `08_OPTIONAL_PHOENIX_LIVEVIEW_CONTROL_SURFACE.md`
6. `09_ROADMAP_PHASE_GATES.md`
7. `checklists/mvp_acceptance_checklist.md`

## Package map

```text
ultimate_cli_first_agent_plan/
  README.md
  MANIFEST.json
  00_SOURCE_REVIEW_AND_DECISIONS.md
  01_ULTIMATE_PLAN.md
  02_ARCHITECTURE_AND_BOUNDARIES.md
  03_RUNTIME_PUBLIC_API.md
  04_CLI_CONTRACT.md
  05_STORAGE_EVENTS_DURABLE_EXECUTION.md
  06_POLICY_SAFETY_APPROVALS.md
  07_PROMPTS_CONTEXT_PROVIDERS_AGENTS.md
  08_OPTIONAL_PHOENIX_LIVEVIEW_CONTROL_SURFACE.md
  09_ROADMAP_PHASE_GATES.md
  10_TESTING_OBSERVABILITY_RELEASE.md
  11_RISKS_DEFERRALS.md
  checklists/
  diagrams/
  implementation/
```

## Non-negotiable outcome

The first accepted release is a working `tet_standalone` CLI release that contains no Phoenix, LiveView, Plug, Cowboy, Phoenix.PubSub, or `TetWeb.*` closure.

The optional Phoenix release is accepted only when removing `apps/tet_web_phoenix` does not break compile, tests, CLI behavior, runtime behavior, storage, approvals, provider calls, artifacts, or the standalone release.
