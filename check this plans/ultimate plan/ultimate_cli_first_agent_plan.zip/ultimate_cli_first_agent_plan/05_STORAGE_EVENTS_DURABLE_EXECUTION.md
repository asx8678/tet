# 05 — Storage, Events, and Durable Execution

## Storage default

Standalone v1 stores state in the workspace:

```text
repo-root/.tet/
  tet.sqlite
  config.toml
  prompts/
    base.md
    mode_chat.md
    mode_explore.md
    mode_execute.md
    policy.md
    tool_cards.md
    verifier.md
  artifacts/
    diffs/
    stdout/
    stderr/
    file_snapshots/
    prompt_debug/
    provider_payload/
    context_snapshots/
    patch_receipts/
    rollback_receipts/
  cache/
  locks/
```

## Store adapters

```text
Tet.Store.Memory     tests
Tet.Store.SQLite     default standalone
Tet.Store.Postgres   optional server/team mode
```

All adapters implement the same behaviour and pass the same contract tests.

## Core records

Required v1 records:

```text
workspaces
sessions
tasks
messages
tool_runs
approvals
artifacts
events
context_snapshots
provider_calls
patch_sets
verifier_runs
workflows
workflow_steps
error_records
```

Optional later records:

```text
agent_profiles
mcp_servers
remote_targets
budget_ledgers
repair_attempts
analytics_findings
operator_accounts
team_memberships
```

## Codec rule

Store adapters must never call `String.to_atom/1` or `String.to_existing_atom/1` on persisted user/input strings.

`tet_core` provides explicit codecs:

```elixir
Tet.Codec.encode_session_mode/1
Tet.Codec.decode_session_mode/1
Tet.Codec.encode_event_type/1
Tet.Codec.decode_event_type/1
# etc.
```

Unknown database values fail with clear migration/config errors.

## Event stream

Events are append-only, typed, and monotonic per session.

```text
session_id + seq is unique
seq starts at 1 per session
event id is globally unique
payload is versioned JSON
```

Events are not a vague log. They are typed user-visible facts.

## Workflow journal

A workflow is one agent execution bound to a session and active task.

A step is one idempotent operation inside that workflow.

```text
compose_prompt
provider_call:attempt:1
tool_run:read_file
tool_run:propose_patch
patch_apply
patch_rollback
verifier_run:mix_test
emit_event
```

Step name grammar:

```text
^[a-z_]+(:[a-z0-9_]+)*$
```

Dots are reserved for event types.

## Journal rule

Every step is recorded before its side effect runs.

```text
start_step
  -> execute side effect
  -> commit_step or fail_step
  -> emit event projection
```

The journal is source of truth for workflow recovery. Events are projections for UI and history.

## Idempotency keys

Each step has an idempotency key:

```text
sha256(workflow_id | step_name | canonical_json(scoped_input))
```

Scoped input examples:

| Step | Scoped input |
|---|---|
| `compose_prompt` | system prompt hash, mode, category, agent profile id, user prompt text, message-history hash |
| `provider_call:attempt:N` | compose prompt output id, provider, model, attempt |
| `tool_run:<tool>` | tool name and canonical args; plus diff sha for patch proposal |
| `patch_apply` | approval id and diff sha |
| `patch_rollback` | approval id |
| `verifier_run:<name>` | verifier name and post-apply workspace hash |
| `emit_event` | event type and canonical payload |

A unique index on `(workflow_id, idempotency_key)` enforces exactly-once commit per logical step.

## Crash recovery

On boot, recovery scans pending workflows.

| Last started step | Recovery behavior |
|---|---|
| `compose_prompt` | Re-run; pure/idempotent. |
| `provider_call:attempt:N` | Mark attempt failed and retry if budget remains; report possible uncommitted provider attempt. |
| read tool | Re-run if safe. |
| `tool_run:propose_patch` | Reuse content-addressed diff artifact if present, otherwise fail/retry. |
| `patch_apply` without manifest | No files touched; mark failed. |
| `patch_apply` with manifest | Run idempotent rollback; mark workflow failed with recovery reason. |
| `patch_rollback` | Re-run rollback. |
| verifier | Re-run with same idempotency scope. |
| `emit_event` | Mark committed; subscribers dedupe by event id. |

## Approval pause

When a workflow creates a pending approval, it enters `paused_for_approval` and exits cleanly. No process must remain alive while waiting for a human.

When the user approves or rejects, the runtime starts a new executor, reloads journal state, and proceeds.

## Artifact rules

Artifacts are content-addressed where possible.

Required artifact kinds:

```text
diff
stdout
stderr
file_snapshot
prompt_debug
provider_payload
context_snapshot
patch_receipt
rollback_receipt
verifier_report
```

Every artifact stores:

```text
id
short_id
kind
path or inline content
sha256
size_bytes
media_type
redacted flag
privacy
created_at
metadata
```

Large artifacts live as files under `.tet/artifacts/`; metadata lives in SQLite.

## Context snapshots

Every provider call in explore/execute records a context snapshot explaining:

- included files;
- skipped files;
- truncated files;
- redacted regions;
- byte/token estimates;
- hashes;
- `.gitignore` and `.tetignore` effects.

This prevents invisible repository reads.

## Migration rule

`tet doctor` checks:

- SQLite schema version;
- expected app schema version;
- presence and permissions of `.tet/` directories;
- artifact root writability;
- lock health;
- provider/secrets configuration;
- configured verifiers;
- git availability/version;
- forbidden unsafe config.

If migration is needed, `tet doctor` must explain what command to run. Automatic destructive migration is forbidden.
