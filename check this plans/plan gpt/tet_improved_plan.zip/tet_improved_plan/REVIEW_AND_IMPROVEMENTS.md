# Review of the Original Plan and Improvements

## Overall assessment

The original plan is directionally correct. Its strongest decisions are:

- Tet is a standalone Elixir/OTP runtime first.
- The CLI is the default product surface.
- Phoenix LiveView is optional and must not own runtime logic.
- `tet_core` remains pure.
- `tet_runtime` owns side effects, session workers, tools, providers, policy enforcement, prompt composition, storage dispatch, verification, and patch application.
- The CLI and optional Phoenix UI call a public `Tet.*` facade.
- Patches are proposed as diffs and require user approval before application.
- Verification uses named allowlisted commands rather than arbitrary shell strings.

The original package is a good architecture plan, but it needs more execution detail before implementation. This improved package fills those gaps.

## Gaps found

### 1. MVP scope was still too broad

The original plan listed many commands and phases, but it did not strongly separate **must-have CLI v1** from later quality-of-life features. This creates risk of building too many surfaces before the first end-to-end product works.

Improvement: define a smaller CLI v1 and defer Phoenix, Postgres, daemon mode, TUI, planner, repair loop, remote execution, long-term memory, and Prompt Lab.

### 2. Provider behavior needed a contract

The original plan mentioned provider adapters, but not enough detail about request metadata, model selection, streaming normalization, retries, rate limits, token limits, cost/usage records, raw payload artifacts, or debugging.

Improvement: add a provider behavior, provider-call records, prompt hashes, usage fields, timeout/retry policy, payload redaction, and prompt debug artifacts.

### 3. Prompt layering needed to be explicit

The original plan had prompt debug and prompt files, but it did not fully define how final prompts are assembled.

Improvement: specify prompt layers: base, mode, policy, tool cards, workspace summary, selected context, conversation window, user message, and optional verifier/patch instructions.

### 4. Context selection was under-specified

Explore and execute modes need deterministic rules for which files are read, skipped, summarized, or truncated.

Improvement: add a context builder with `.tetignore`, `.gitignore`, binary detection, large-file caps, generated-directory skips, token budgets, context snapshots, and redaction.

### 5. Patch approval needed stronger recovery guarantees

The original plan required approval and patch clean-apply checks, which is good. It did not fully define approval expiration, patch hashing, target-file content checks, rollback, snapshots, or dirty-tree behavior.

Improvement: add patch hashes, target file before-hashes, file snapshots, rollback artifacts, approval expiry, revalidation before apply, and a dirty-git policy.

### 6. SQLite schema needed to be concrete

The original plan defined entities but not a full initial schema.

Improvement: include a v1 SQL schema with tables, indexes, event sequencing, provider calls, verifier runs, context snapshots, approvals, artifacts, and schema migrations.

### 7. Security and privacy needed more first-class treatment

The original plan mentioned redaction and path checks. It needed stronger controls around environment variables, `.tet/` access, secret detection, artifact privacy, and adversarial tests.

Improvement: add redaction stages, `.tet/` write protection, env scrubbing, `.tetignore`, path/symlink adversarial cases, output caps, and secrets tests.

### 8. CLI should be scriptable

The original CLI was user-friendly but did not fully specify JSON output and noninteractive behavior.

Improvement: add `--json` support for major read commands, deterministic output schemas, stable exit codes, `tet explain`, and machine-readable event streams.

### 9. Tests needed to be earlier in the roadmap

The original roadmap placed hardening late. For an agent that can touch files, safety tests should arrive before the agent loop becomes complex.

Improvement: move policy and path/security tests into the first implementation gates.

### 10. Phoenix optionality should be proven continuously

The original plan had dependency guards, but the improved plan makes Phoenix removability a recurring CI gate rather than a final check only.

Improvement: each phase that changes dependencies must run standalone closure checks and a Phoenix-removal compile/test check.

## Highest-priority improvements

The five most important changes are:

1. **Constrain v1** to a working standalone CLI before any Phoenix adapter.
2. **Build policy tests early**, before the provider/tool loop becomes complex.
3. **Add context builder and redaction** before repository inspection.
4. **Add patch snapshots, revalidation, expiration, and rollback artifacts** before applying any patch.
5. **Persist provider calls, prompt debug, context snapshots, and verifier output** to make every agent decision auditable.

## Improved success definition

Tet v1 succeeds when this works from a clean standalone release:

```bash
tet init . --trust
tet doctor
S_CHAT=$(tet session new . --mode chat --json | jq -r .session.short_id)
tet ask "$S_CHAT" "what does this repo do?"
S_EXPLORE=$(tet session new . --mode explore --json | jq -r .session.short_id)
tet explore "$S_EXPLORE" "find the main entrypoint"
S_EXEC=$(tet session new . --mode execute --json | jq -r .session.short_id)
tet edit "$S_EXEC" "add a short README note"
tet approvals "$S_EXEC"
tet patch approve APPROVAL_ID
tet verify "$S_EXEC" mix_test
tet explain "$S_EXEC"
tet status "$S_EXEC"
```

And the `tet_standalone` release contains no Phoenix, LiveView, Plug, Cowboy, or `TetWeb.*` dependency closure.
