# Implementation — Mix and Release Profiles

## Root release sketch

```elixir
defmodule Tet.Umbrella.MixProject do
  use Mix.Project

  def project do
    [
      apps_path: "apps",
      version: "0.1.0",
      start_permanent: Mix.env() == :prod,
      deps: [],
      releases: releases(),
      aliases: aliases()
    ]
  end

  defp aliases do
    [
      "ci.guards": [
        "cmd tools/check_imports.sh",
        "cmd tools/check_xref.sh",
        "cmd tools/check_release_closure.sh",
        "cmd tools/check_phoenix_removable.sh"
      ],
      "ci.acceptance": [
        "compile --warnings-as-errors",
        "test",
        "ci.guards"
      ]
    ]
  end

  defp releases do
    [
      tet_standalone: [
        applications: [
          tet_core: :permanent,
          tet_store_sqlite: :permanent,
          tet_runtime: :permanent,
          tet_cli: :permanent
        ],
        include_executables_for: [:unix]
      ],
      tet_runtime_only: [
        applications: [
          tet_core: :permanent,
          tet_store_sqlite: :permanent,
          tet_runtime: :permanent
        ],
        include_executables_for: [:unix]
      ],
      tet_web: [
        applications: [
          tet_core: :permanent,
          tet_store_sqlite: :permanent,
          tet_runtime: :permanent,
          tet_web_phoenix: :permanent
        ],
        include_executables_for: [:unix]
      ]
    ]
  end
end
```

## Standalone forbidden closure

The standalone release must not include libraries whose names start with:

```text
phoenix
phoenix_live_view
phoenix_pubsub
plug
cowboy
```

Nor should it include application modules under:

```text
TetWeb
TetWebPhoenix
```

## Provider dependencies

For v1, keep one provider adapter small. If a provider client pulls heavy dependencies or web frameworks, move it to an optional provider app and ensure `tet_standalone` can be built with a fake/local provider for tests.
