# Implementation — Guard Scripts

## `tools/check_imports.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-.}"
status=0
fail() { echo "FAIL: $*"; status=1; }

check_forbidden() {
  local name="$1"; shift
  local pattern="$1"; shift
  local paths=("$@")
  for p in "${paths[@]}"; do
    [ -e "$p" ] || continue
    if grep -RE "$pattern" --include='*.ex' --include='*.exs' "$p"; then
      fail "forbidden reference in $name"
    fi
  done
}

check_forbidden tet_core 'Tet\.Runtime|TetWeb|Phoenix|Plug\.|Ecto|Tet\.CLI|Tet\.Store\.SQLite' \
  "$ROOT/apps/tet_core/lib" "$ROOT/apps/tet_core/test"

check_forbidden tet_runtime 'TetWeb|Phoenix|Plug\.|Tet\.CLI' \
  "$ROOT/apps/tet_runtime/lib" "$ROOT/apps/tet_runtime/test"

check_forbidden tet_cli 'TetWeb|Phoenix|Plug\.|Tet\.Store\.|Tet\.Runtime\.|Tet\.Tools\.|Tet\.Prompt\.' \
  "$ROOT/apps/tet_cli/lib" "$ROOT/apps/tet_cli/test"

for app in tet_store_memory tet_store_sqlite tet_store_postgres; do
  check_forbidden "$app" 'Tet\.Runtime|Tet\.CLI|TetWeb|Phoenix|Plug\.' \
    "$ROOT/apps/$app/lib" "$ROOT/apps/$app/test"
done

[ "$status" -eq 0 ] && echo "OK: source guard clean"
exit "$status"
```

## `tools/check_release_closure.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail
MIX_ENV=prod mix release tet_standalone --overwrite
REL_DIR="_build/prod/rel/tet_standalone/lib"

leaked=$(ls "$REL_DIR" | grep -E '^(phoenix|phoenix_live_view|phoenix_pubsub|plug|cowboy|phoenix_html)' || true)

if [ -n "$leaked" ]; then
  echo "FAIL: forbidden libraries in tet_standalone release closure:"
  echo "$leaked"
  exit 1
fi

echo "OK: tet_standalone release closure is clean"
```

## `tools/check_phoenix_removable.sh`

```bash
#!/usr/bin/env bash
set -euo pipefail

if [ ! -d apps/tet_web_phoenix ]; then
  echo "OK: no Phoenix app present"
  exit 0
fi

tmp="/tmp/tet_web_phoenix_backup_$$"
mv apps/tet_web_phoenix "$tmp"
restore() { mv "$tmp" apps/tet_web_phoenix; }
trap restore EXIT

mix compile --warnings-as-errors
mix test
MIX_ENV=prod mix release tet_standalone --overwrite

echo "OK: Phoenix app is removable"
```
