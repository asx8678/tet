# Implementation — Policy Test Matrix

## Mode tests

- [ ] chat blocks `list_dir`.
- [ ] chat blocks `read_file`.
- [ ] chat blocks `search_text`.
- [ ] chat blocks `git_status`.
- [ ] chat blocks `git_diff`.
- [ ] chat blocks `propose_patch`.
- [ ] chat blocks `run_command`.
- [ ] explore allows read tools.
- [ ] explore blocks `propose_patch`.
- [ ] explore blocks `apply_approved_patch`.
- [ ] explore blocks `run_command`.
- [ ] execute allows read tools.
- [ ] execute allows `propose_patch` only as pending approval.
- [ ] execute blocks patch apply without approved approval.
- [ ] execute blocks verifier names not in allowlist.

## Path tests

- [ ] rejects `../outside.txt`.
- [ ] rejects absolute path outside workspace.
- [ ] rejects nested traversal `subdir/../../outside.txt`.
- [ ] rejects symlink to outside workspace.
- [ ] rejects `.git/config` direct read.
- [ ] rejects `.tet/tet.sqlite` direct agent read.
- [ ] rejects patch targeting `.tet/` by default.
- [ ] rejects patch targeting `.git/`.
- [ ] handles case sensitivity correctly on platform.

## Size and binary tests

- [ ] `read_file` truncates or blocks oversized files.
- [ ] binary file returns summary, not raw bytes.
- [ ] search caps result count.
- [ ] search caps total result bytes.
- [ ] patch over max bytes is blocked.
- [ ] verifier stdout/stderr are capped.

## Approval tests

- [ ] `propose_patch` creates diff artifact and pending approval.
- [ ] no disk changes before approval.
- [ ] rejected approval changes no files.
- [ ] approved patch applies if preflight passes.
- [ ] expired approval cannot apply.
- [ ] changed patch hash cannot apply.
- [ ] changed target file is refused by default.
- [ ] second pending approval in same session is refused in v1.

## Command execution tests

- [ ] raw shell string is rejected.
- [ ] `mix_test && rm -rf /` is treated as a verifier name and rejected.
- [ ] argv command runs without shell interpolation.
- [ ] env is scrubbed.
- [ ] timeout terminates verifier.

## Redaction tests

- [ ] bearer token redacted.
- [ ] private key block redacted.
- [ ] `.env` secret redacted.
- [ ] database URL password redacted.
- [ ] authorization header redacted.
- [ ] redaction metadata persists.
