# Implementation — Module Map

## `tet_core`

```text
apps/tet_core/lib/tet/
  workspace.ex
  session.ex
  task.ex
  message.ex
  tool_run.ex
  approval.ex
  artifact.ex
  event.ex
  provider_call.ex
  verifier_run.ex
  context_snapshot.ex
  patch_set.ex
  command.ex
  error.ex
  ids.ex
  redactor.ex
  policy.ex
  policy/
    mode_policy.ex
    trust_policy.ex
    path_policy.ex
    approval_policy.ex
    command_policy.ex
    limits_policy.ex
  patch/
    diff.ex
    patch_set.ex
    validator.ex
  provider.ex
  tool.ex
  store.ex
```

## `tet_runtime`

```text
apps/tet_runtime/lib/
  tet.ex
  tet/application.ex
  tet/runtime.ex
  tet/event_bus.ex
  tet/config/loader.ex
  tet/runtime/session_registry.ex
  tet/runtime/session_supervisor.ex
  tet/runtime/session_worker.ex
  tet/agent/runtime_supervisor.ex
  tet/agent/runtime.ex
  tet/agent/loop.ex
  tet/agent/tool_intent_parser.ex
  tet/context/builder.ex
  tet/context/ignore_rules.ex
  tet/context/token_budget.ex
  tet/prompt/composer.ex
  tet/prompt/defaults.ex
  tet/prompt/file_store.ex
  tet/prompt/debug.ex
  tet/provider/adapter.ex
  tet/provider/fake.ex
  tet/provider/normalizer.ex
  tet/tool/executor.ex
  tet/tool/task_supervisor.ex
  tet/tools/local_fs.ex
  tet/tools/search.ex
  tet/tools/git.ex
  tet/tools/patch.ex
  tet/tools/verifier.ex
  tet/path/resolver.ex
  tet/artifact/writer.ex
  tet/patch/applier.ex
  tet/patch/rollback.ex
  tet/verification/runner.ex
  tet/storage/dispatcher.ex
```

## `tet_cli`

```text
apps/tet_cli/lib/tet/cli/
  main.ex
  argv.ex
  json.ex
  exit_codes.ex
  commands/
    doctor.ex
    init.ex
    workspace.ex
    session.ex
    chat.ex
    ask.ex
    explore.ex
    edit.ex
    approvals.ex
    patch_approve.ex
    patch_reject.ex
    patch_rollback.ex
    verify.ex
    status.ex
    explain.ex
    prompt_debug.ex
    events_tail.ex
  render/
    timeline.ex
    diff.ex
    tool_run.ex
    verifier.ex
    errors.ex
    status.ex
    explain.ex
```

## `tet_store_sqlite`

```text
apps/tet_store_sqlite/lib/tet/store/sqlite/
  application.ex
  repo.ex
  store.ex
  migrations.ex
  schemas/
    workspace.ex
    session.ex
    task.ex
    message.ex
    tool_run.ex
    approval.ex
    artifact.ex
    event.ex
    provider_call.ex
    verifier_run.ex
    context_snapshot.ex
    patch_set.ex
```
