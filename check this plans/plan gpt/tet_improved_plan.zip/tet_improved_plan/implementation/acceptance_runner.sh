#!/usr/bin/env bash
set -euo pipefail

printf '\n== guards ==\n'
tools/check_imports.sh
tools/check_xref.sh

printf '\n== compile ==\n'
mix compile --warnings-as-errors

printf '\n== tests ==\n'
mix test

printf '\n== standalone release closure ==\n'
tools/check_release_closure.sh

printf '\n== Phoenix removability ==\n'
if [ -x tools/check_phoenix_removable.sh ]; then
  tools/check_phoenix_removable.sh
fi

printf '\n== standalone smoke ==\n'
_build/prod/rel/tet_standalone/bin/tet doctor

printf '\nALL ACCEPTANCE CHECKS PASSED\n'
