defmodule Tet.Provider do
  @moduledoc """
  Provider behaviour for normalized LLM interactions.

  This belongs in tet_core. Concrete adapters may live in tet_runtime for v1
  or in separate tet_provider_* apps later.
  """

  @type request :: %{
          required(:messages) => [map()],
          required(:model) => binary(),
          optional(:tools) => [map()],
          optional(:temperature) => number(),
          optional(:max_output_tokens) => pos_integer(),
          optional(:metadata) => map()
        }

  @type event ::
          {:text_delta, binary()}
          | {:tool_call_delta, map()}
          | {:tool_call_completed, map()}
          | {:usage, map()}
          | {:finish, map()}
          | {:error, Tet.Error.t()}

  @callback stream_chat(request(), keyword()) ::
              {:ok, Enumerable.t()} | {:error, Tet.Error.t()}

  @callback chat(request(), keyword()) ::
              {:ok, map()} | {:error, Tet.Error.t()}
end
