defmodule Tet.Store do
  @moduledoc """
  Store behaviour implemented by memory, SQLite, and future Postgres adapters.
  """

  @callback transaction((-> term())) :: {:ok, term()} | {:error, term()}

  @callback create_workspace(map()) :: {:ok, Tet.Workspace.t()} | {:error, term()}
  @callback get_workspace(binary()) :: {:ok, Tet.Workspace.t()} | {:error, term()}
  @callback set_trust(binary(), atom()) :: {:ok, Tet.Workspace.t()} | {:error, term()}

  @callback create_session(map()) :: {:ok, Tet.Session.t()} | {:error, term()}
  @callback update_session(binary(), map()) :: {:ok, Tet.Session.t()} | {:error, term()}
  @callback get_session(binary()) :: {:ok, Tet.Session.t()} | {:error, term()}
  @callback list_sessions(binary(), keyword()) :: {:ok, [Tet.Session.t()]} | {:error, term()}

  @callback create_task(map()) :: {:ok, Tet.Task.t()} | {:error, term()}
  @callback append_message(map()) :: {:ok, Tet.Message.t()} | {:error, term()}

  @callback record_tool_run(map()) :: {:ok, Tet.ToolRun.t()} | {:error, term()}
  @callback update_tool_run(binary(), map()) :: {:ok, Tet.ToolRun.t()} | {:error, term()}

  @callback create_context_snapshot(map()) :: {:ok, Tet.ContextSnapshot.t()} | {:error, term()}
  @callback record_provider_call(map()) :: {:ok, Tet.ProviderCall.t()} | {:error, term()}
  @callback update_provider_call(binary(), map()) :: {:ok, Tet.ProviderCall.t()} | {:error, term()}

  @callback create_patch_set(map()) :: {:ok, Tet.PatchSet.t()} | {:error, term()}
  @callback update_patch_set(binary(), map()) :: {:ok, Tet.PatchSet.t()} | {:error, term()}

  @callback create_approval(map()) :: {:ok, Tet.Approval.t()} | {:error, term()}
  @callback resolve_approval(binary(), atom(), map()) :: {:ok, Tet.Approval.t()} | {:error, term()}
  @callback expire_approvals(DateTime.t()) :: {:ok, non_neg_integer()} | {:error, term()}
  @callback get_approval(binary()) :: {:ok, Tet.Approval.t()} | {:error, term()}
  @callback list_approvals(binary(), keyword()) :: {:ok, [Tet.Approval.t()]} | {:error, term()}

  @callback create_verifier_run(map()) :: {:ok, Tet.VerifierRun.t()} | {:error, term()}
  @callback update_verifier_run(binary(), map()) :: {:ok, Tet.VerifierRun.t()} | {:error, term()}

  @callback create_artifact(map()) :: {:ok, Tet.Artifact.t()} | {:error, term()}
  @callback get_artifact(binary()) :: {:ok, Tet.Artifact.t()} | {:error, term()}

  @callback emit_event(map()) :: {:ok, Tet.Event.t()} | {:error, term()}
  @callback list_events(binary(), keyword()) :: {:ok, [Tet.Event.t()]} | {:error, term()}
end
