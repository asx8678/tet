# Tet Improved Plan Package

This package is a revised implementation plan for **Tet**, a standalone **Elixir/OTP CLI-first coding-agent runtime** with Phoenix LiveView as an optional adapter only.

The original plan was already strong on the major architecture decision: runtime, policies, storage, tools, approvals, providers, patching, and verification must live outside Phoenix. This improved version keeps that decision and makes the plan more executable.

## What changed from the original plan

The improved plan adds stronger detail in these areas:

1. **Sharper MVP definition** — a smaller, testable CLI v1 with clear non-goals.
2. **Phase gates** — every phase now has entry criteria, deliverables, tests, and exit criteria.
3. **Provider and prompt contracts** — provider behavior, prompt layering, payload persistence, retries, usage, token budgets, and debugging are specified.
4. **Context builder** — file selection, `.tetignore`, binary/large-file handling, truncation, and redaction rules are first-class.
5. **Patch safety** — approval expiration, patch hashes, changed-file revalidation, file snapshots, rollback artifacts, and dirty-git handling are defined.
6. **Concrete storage schema** — a v1 SQLite schema, indexes, artifact metadata, event sequencing, provider calls, verifier runs, and context snapshots are included.
7. **Security and privacy** — secret redaction, environment scrubbing, `.tet/` protection, path/symlink escape checks, output limits, and adversarial tests are explicit.
8. **CLI UX** — human and JSON output, deterministic exit codes, noninteractive behavior, and explain/status commands are specified.
9. **Testing strategy** — policy tests, storage contract tests, CLI golden tests, end-to-end demo, release closure tests, and Phoenix removability checks are included.
10. **Acceptance checklists** — go/no-go criteria are grouped for MVP, safety, and release.

## Recommended reading order

1. `MASTER_IMPROVED_PLAN.md`
2. `REVIEW_AND_IMPROVEMENTS.md`
3. `docs/01_mvp_scope_and_non_goals.md`
4. `docs/02_architecture_and_dependency_boundaries.md`
5. `docs/05_context_prompt_provider.md`
6. `docs/07_patch_approval_rollback_verification.md`
7. `docs/11_roadmap_phase_gates.md`
8. `checklists/mvp_exit_criteria.md`
9. `implementation/sqlite_schema_v1.sql`
10. `implementation/demo_v1.sh`

## Package layout

```text
tet_improved_plan/
  README.md
  MASTER_IMPROVED_PLAN.md
  REVIEW_AND_IMPROVEMENTS.md
  docs/
    01_mvp_scope_and_non_goals.md
    02_architecture_and_dependency_boundaries.md
    03_runtime_public_api.md
    04_storage_schema_events_artifacts.md
    05_context_prompt_provider.md
    06_tools_policy_security.md
    07_patch_approval_rollback_verification.md
    08_cli_contract_json_exit_codes.md
    09_testing_acceptance_release.md
    10_phoenix_optional_adapter.md
    11_roadmap_phase_gates.md
    12_risks_mitigations.md
  diagrams/
    architecture.mmd
    dependency_rules.mmd
    event_storage_flow.mmd
    patch_workflow.mmd
    session_flow.mmd
  implementation/
    acceptance_runner.sh
    demo_v1.sh
    guard_scripts.md
    mix_release_profiles.md
    module_map.md
    policy_test_matrix.md
    provider_behavior_sketch.ex
    sqlite_schema_v1.sql
    store_behavior_sketch.ex
    tet_config_example.toml
    tetignore_example
  checklists/
    mvp_exit_criteria.md
    release_checklist.md
    safety_acceptance_checklist.md
  assets/
    tet_cli_coding_agent_roadmap_overview.png
  MANIFEST.json
```

## One-sentence improved plan

Build Tet v1 as a safe, local-first CLI agent that can chat, inspect a repository, propose patches, require explicit approval, apply only approved patches, run allowlisted verification, and persist a complete auditable timeline — with Phoenix remaining genuinely optional.
