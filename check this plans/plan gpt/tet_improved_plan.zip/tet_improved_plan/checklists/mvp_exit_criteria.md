# MVP Exit Criteria

## Workspace

- [ ] `tet init . --trust` creates `.tet/` layout.
- [ ] `.tet/config.toml` parses.
- [ ] SQLite opens and migrations are current.
- [ ] `tet doctor` passes.

## Sessions

- [ ] chat session can be created.
- [ ] explore session can be created.
- [ ] execute session can be created.
- [ ] sessions persist across CLI invocations.
- [ ] events persist with monotonic sequence numbers.

## Chat

- [ ] `tet ask` works with no repo tools.
- [ ] provider call is persisted.
- [ ] prompt debug artifact can be saved.

## Explore

- [ ] read tools work inside workspace.
- [ ] path escapes are blocked.
- [ ] `.tet/` and `.git/` internals are blocked by default.
- [ ] context snapshot records included/skipped files.

## Execute

- [ ] `tet edit` proposes a patch and exits code 3.
- [ ] no files change before approval.
- [ ] diff artifact is saved.
- [ ] patch set and approval rows are created.
- [ ] approval can be rejected with no file changes.
- [ ] approval can be approved and applied by runtime.
- [ ] expired or invalid approval is refused.

## Verification

- [ ] named verifier runs.
- [ ] raw shell is rejected.
- [ ] stdout/stderr artifacts are saved.
- [ ] output is capped and redacted.

## Auditability

- [ ] `tet status` summarizes current state.
- [ ] `tet explain` explains the session.
- [ ] artifacts are discoverable by id.
- [ ] provider calls, context snapshots, tool runs, approvals, patches, verifier runs, and events are linked.
