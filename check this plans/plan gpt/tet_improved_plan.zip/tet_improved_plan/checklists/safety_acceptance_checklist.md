# Safety Acceptance Checklist

## Repository access

- [ ] Chat mode has no repository tools.
- [ ] Explore mode has read-only tools only.
- [ ] Execute mode cannot write without approval.
- [ ] No direct file write tool exists in v1.
- [ ] No delete tool exists in v1.

## Path safety

- [ ] `..` traversal blocked.
- [ ] absolute path outside workspace blocked.
- [ ] symlink escape blocked.
- [ ] `.git/` internals blocked.
- [ ] `.tet/` internals blocked from agent tools.
- [ ] platform case-sensitivity behavior tested.

## Patch safety

- [ ] patch must be unified diff.
- [ ] patch size limit enforced.
- [ ] patch paths must be inside workspace.
- [ ] patch cannot target `.git/`.
- [ ] patch cannot target `.tet/` by default.
- [ ] approval expires.
- [ ] patch hash rechecked before apply.
- [ ] target file hashes rechecked before apply.
- [ ] snapshots saved before apply when practical.
- [ ] rollback artifact exists or manual recovery instructions are shown.

## Command safety

- [ ] verifier names come from allowlist.
- [ ] verifier is argv array, not shell string.
- [ ] env is scrubbed.
- [ ] timeout enforced.
- [ ] stdout/stderr caps enforced.

## Secrets

- [ ] `.tetignore` honored.
- [ ] `.env` skipped by default.
- [ ] API keys redacted.
- [ ] bearer tokens redacted.
- [ ] private keys redacted.
- [ ] database URLs redacted.
- [ ] redaction metadata persisted.

## Dependency safety

- [ ] `tet_core` has no runtime/web/store implementation deps.
- [ ] `tet_runtime` has no Phoenix/Plug/Cowboy deps.
- [ ] `tet_cli` calls only `Tet.*`.
- [ ] standalone release has no web dependency closure.
- [ ] Phoenix app can be removed without breaking standalone build.
