# Release Checklist

## Build

- [ ] `mix compile --warnings-as-errors` passes.
- [ ] `mix test` passes.
- [ ] guard scripts pass.
- [ ] `MIX_ENV=prod mix release tet_standalone --overwrite` passes.
- [ ] standalone release boots.
- [ ] `tet doctor` passes from release binary.

## Closure

- [ ] no Phoenix libraries in standalone release.
- [ ] no LiveView libraries in standalone release.
- [ ] no Plug/Cowboy libraries in standalone release.
- [ ] no `TetWeb.*` modules in standalone release.

## Docs

- [ ] CLI help is accurate.
- [ ] config example is accurate.
- [ ] `.tetignore` example is included.
- [ ] safety model is documented.
- [ ] verification allowlist is documented.
- [ ] approval workflow is documented.

## Demo

- [ ] `implementation/demo_v1.sh` passes in fixture repo.
- [ ] demo produces pending approval.
- [ ] approval apply works.
- [ ] verifier runs.
- [ ] `tet explain` produces useful summary.

## Package

- [ ] release tarball created.
- [ ] SHA256 checksum created.
- [ ] install instructions included.
- [ ] version number set.
- [ ] changelog entry added.
