# Master Improved Plan — Tet Standalone CLI Coding-Agent Runtime

## Executive decision

Build **Tet** as a standalone **Elixir/OTP coding-agent runtime** with a **CLI-first product surface**. Phoenix LiveView remains optional and may only render or control the same runtime through the public `Tet.*` API.

```text
Tet must run through Elixir/OTP, not through Phoenix.
Phoenix may render Tet, but Phoenix must never own Tet.
```

## Product promise for v1

Tet v1 is a safe local CLI agent that can:

1. initialize a local repository workspace;
2. create chat, explore, and execute sessions;
3. chat without repository access;
4. inspect repository files in read-only mode;
5. propose code patches in execute mode;
6. require explicit user approval before patch application;
7. apply only approved, still-valid patches;
8. run only named allowlisted verifiers;
9. persist sessions, messages, tool runs, approvals, artifacts, provider calls, verifier runs, context snapshots, and events;
10. provide an auditable timeline through CLI commands and event streams.

## Final umbrella layout

```text
tet_umbrella/
  mix.exs
  config/
  tools/
  apps/
    tet_core/             # pure domain contracts, structs, policies, behaviours
    tet_runtime/          # OTP app, public Tet facade, sessions, event bus, tools, providers
    tet_cli/              # standalone terminal product
    tet_store_memory/     # test adapter
    tet_store_sqlite/     # default local store
    tet_store_postgres/   # future optional team/server store, not v1 implementation
    tet_web_phoenix/      # future optional LiveView adapter, post-v1
```

Provider adapters may initially live inside `tet_runtime`. If provider dependencies become heavy, move them to optional `tet_provider_*` apps that depend on `tet_core` contracts and are loaded by runtime configuration.

## Dependency rule

```text
tet_cli ──────────┐
                  ├──► tet_runtime ───► tet_core
tet_web_phoenix ──┘          │
                             ├──► configured provider adapter
                             └──► configured store adapter ───► tet_core
```

Forbidden outside `tet_web_phoenix`:

```text
Phoenix
Phoenix.LiveView
Phoenix.PubSub
Plug
Cowboy
TetWeb.*
```

## Required v1 apps

Implement for v1:

```text
tet_core
tet_runtime
tet_cli
tet_store_memory
tet_store_sqlite
```

Create only stubs or postponed contracts for:

```text
tet_store_postgres
tet_web_phoenix
tet_provider_*
```

## Core domain objects

```text
Tet.Workspace
Tet.Session
Tet.Task
Tet.Message
Tet.ToolRun
Tet.Approval
Tet.Artifact
Tet.Event
Tet.ProviderCall
Tet.VerifierRun
Tet.ContextSnapshot
Tet.PatchSet
Tet.Error
```

## Public facade

All user-facing adapters call only the `Tet` facade from `tet_runtime`:

```elixir
Tet.init_workspace(path, opts)
Tet.trust_workspace(workspace_ref, opts)
Tet.get_workspace(workspace_ref)
Tet.start_session(workspace_ref, opts)
Tet.list_sessions(workspace_ref, opts)
Tet.get_session(session_ref, opts)
Tet.send_prompt(session_ref, prompt, opts)
Tet.list_approvals(session_ref, opts)
Tet.get_approval(approval_ref, opts)
Tet.approve_patch(approval_ref, opts)
Tet.reject_patch(approval_ref, opts)
Tet.run_verification(session_ref, verifier_name, opts)
Tet.rollback_patch(patch_ref, opts)
Tet.explain(session_ref, opts)
Tet.status(session_ref, opts)
Tet.prompt_debug(session_ref, opts)
Tet.list_events(session_ref, opts)
Tet.subscribe(session_ref, opts)
Tet.lookup(kind, short_id, opts)
Tet.doctor(workspace_ref_or_path, opts)
```

CLI and Phoenix must not call runtime internals.

## CLI v1 commands

Required:

```text
tet doctor
tet init [PATH] [--trust] [--copy-default-prompts]
tet workspace trust PATH
tet workspace info [PATH] [--json]
tet session new PATH [--mode chat|explore|execute] [--provider NAME] [--model ID] [--json]
tet session list [PATH] [--json]
tet session show SESSION_ID [--json]
tet chat SESSION_ID
tet ask SESSION_ID "question" [--json]
tet explore SESSION_ID "inspect this" [--json]
tet edit SESSION_ID "make this change" [--json]
tet approvals SESSION_ID [--json]
tet patch approve APPROVAL_ID [--json]
tet patch reject APPROVAL_ID [--json]
tet patch rollback PATCH_ID [--json]
tet verify SESSION_ID VERIFIER_NAME [--json]
tet status SESSION_ID [--json]
tet explain SESSION_ID [--json]
tet prompt debug SESSION_ID [--save] [--json]
tet events tail SESSION_ID [--json]
```

Explicitly not v1:

```text
tet web
tet daemon
tet tui
tet prompt lab
tet plan
tet run
tet repair
tet remote
tet worker
tet memory
tet migrate
```

## Session modes

| Capability | Chat | Explore | Execute |
|---|:---:|:---:|:---:|
| Provider response | yes | yes | yes |
| Message persistence | yes | yes | yes |
| Event timeline | yes | yes | yes |
| Repository read tools | no | yes | yes |
| Patch proposal | no | no | yes |
| Patch application | no | no | approved only |
| Verification command | no | no | allowlisted only |

## Local workspace layout

```text
repo-root/.tet/
  tet.sqlite
  config.toml
  prompts/
    base.md
    mode_chat.md
    mode_explore.md
    mode_execute.md
    policy.md
    tool_cards.md
    verifier.md
  artifacts/
    diffs/
    stdout/
    stderr/
    file_snapshots/
    prompt_debug/
    provider_payload/
    context_snapshots/
    patch_receipts/
  cache/
  locks/
```

Recommended repo-level ignore file:

```text
.tetignore
```

## Context builder

Repository context must be selected by rules, not by blindly reading the tree.

Default rules:

- respect `.gitignore`;
- respect `.tetignore`;
- never traverse `.git/`;
- hide `.tet/` internals except safe metadata needed by `doctor` and `workspace info`;
- skip binary files;
- skip dependency/build/cache folders by default;
- cap file size and total context bytes;
- redact secrets before provider calls;
- persist a `context_snapshot` artifact explaining what was included, skipped, truncated, and redacted.

## Provider and prompt model

Every provider call persists:

```text
provider name
model id
request id when available
prompt hash
prompt debug artifact id
context snapshot id
input token estimate/count
output token count
latency
finish reason
cost estimate if available
redaction metadata
raw request artifact id, optional and redacted
raw response artifact id, optional and redacted
error details
```

Prompt layers:

```text
base system prompt
mode prompt
policy constraints
tool cards
workspace summary
selected context
conversation window
user message
```

## Patch safety model

Patch proposal does not write files. It creates:

```text
diff artifact
patch set record
changed-file list
before-file hashes
optional file snapshots
pending approval
approval expiration timestamp
risk summary
```

Patch application requires:

```text
trusted workspace
execute session
active task
approved approval
approval not expired
same patch hash
same target files
same workspace/session
policy still passes
paths still inside workspace
file hashes match or rebase policy allows changes
patch applies cleanly
```

Runtime applies patches. CLI and Phoenix never apply patches directly.

## Verification

Only named verifiers from `.tet/config.toml` may run.

Each verifier defines:

```text
command argv array
timeout
stdout/stderr byte cap
env allowlist
working directory
whether failure should block session success
```

No raw shell string is accepted.

## Event log

Events are append-only per session with monotonic sequence numbers.

Examples:

```text
workspace.created
workspace.trusted
session.created
session.status_changed
message.user.saved
message.assistant.saved
context.snapshot.created
provider.call.started
provider.call.completed
provider.call.failed
tool.requested
tool.blocked
tool.started
tool.finished
approval.created
approval.approved
approval.rejected
approval.expired
patch.apply.started
patch.applied
patch.failed
patch.rollback.created
verifier.started
verifier.finished
policy.denied
error.recorded
```

## Revised roadmap

1. Umbrella skeleton and dependency guards.
2. Core structs, command structs, events, errors, IDs, and policy contracts.
3. Policy/path/security test suite.
4. Store behavior, memory store, and event contract tests.
5. SQLite schema, migrations, artifact writer, workspace init.
6. Runtime supervision, public facade, event bus, session workers.
7. CLI foundation, JSON mode, exit codes, doctor/init/session commands.
8. Provider behavior, prompt composer, prompt debug, chat mode.
9. Context builder, `.tetignore`, read tools, explore mode.
10. Patch proposal, approval lifecycle, snapshots, expiration.
11. Patch application, rollback artifacts, dirty-git policy.
12. Verification allowlist, verifier artifacts, output caps.
13. End-to-end demo and acceptance runner.
14. Standalone release profile and release-closure proof.
15. Optional Phoenix adapter only after CLI v1 passes.

## Final acceptance

Tet v1 is accepted when:

```bash
MIX_ENV=prod mix release tet_standalone --overwrite
_build/prod/rel/tet_standalone/bin/tet doctor
implementation/demo_v1.sh
implementation/acceptance_runner.sh
```

all pass, and the standalone release contains no Phoenix, Plug, Cowboy, LiveView, Phoenix.PubSub, or `TetWeb.*` closure.
