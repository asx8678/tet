# 03 — Runtime Public API

## API placement

The public API lives in:

```text
apps/tet_runtime/lib/tet.ex
```

It delegates to runtime internals. It does not live in `tet_core`, because `tet_core` must not depend outward on runtime behavior.

## Required facade functions

```elixir
defmodule Tet do
  # Workspace
  init_workspace(path, opts \\ [])
  trust_workspace(workspace_ref, opts \\ [])
  get_workspace(workspace_ref, opts \\ [])
  workspace_info(workspace_ref, opts \\ [])

  # Sessions
  start_session(workspace_ref, opts \\ [])
  list_sessions(workspace_ref, opts \\ [])
  get_session(session_ref, opts \\ [])

  # Conversation / agent loop
  send_prompt(session_ref, prompt, opts \\ [])
  cancel(session_ref, reason, opts \\ [])

  # Approvals and patches
  list_approvals(session_ref, opts \\ [])
  get_approval(approval_ref, opts \\ [])
  approve_patch(approval_ref, opts \\ [])
  reject_patch(approval_ref, opts \\ [])
  rollback_patch(patch_ref, opts \\ [])

  # Verification
  run_verification(session_ref, verifier_name, opts \\ [])

  # Observability
  status(session_ref, opts \\ [])
  explain(session_ref, opts \\ [])
  prompt_debug(session_ref, opts \\ [])
  list_events(session_ref, opts \\ [])
  subscribe(session_ref, opts \\ [])
  unsubscribe(session_ref, opts \\ [])

  # Lookup and diagnostics
  lookup(kind, short_id, opts \\ [])
  doctor(workspace_ref_or_path \\ nil, opts \\ [])
end
```

## Compatibility rule

Within a major version:

- adding optional opts is allowed;
- adding response fields is allowed;
- adding event fields is allowed;
- removing functions is forbidden;
- changing return tags is forbidden;
- changing required response fields is forbidden;
- changing event type names is forbidden.

## Return shape guideline

Use explicit tagged returns:

```elixir
{:ok, result}
{:error, %Tet.Error{reason: atom(), message: binary(), details: map()}}
```

Avoid returning bare atoms except for simple subscription functions where `:ok` is sufficient.

## Facade-only rule

CLI and Phoenix may reference:

```text
Tet
Tet.Workspace
Tet.Session
Tet.Message
Tet.ToolRun
Tet.Approval
Tet.Artifact
Tet.Event
Tet.Error
```

They may not reference:

```text
Tet.Runtime.*
Tet.EventBus
Tet.Store.*
Tet.Store.SQLite.*
Tet.Tool.*
Tet.Tools.*
Tet.Prompt.*
Tet.Provider.*
Tet.Agent.*
```

If a UI needs more data, add a function to `Tet`, not a direct internal call.

## Event subscription contract

`Tet.subscribe(session_ref)` sends `%Tet.Event{}` messages to the caller.

The event stream is for rendering and progress updates. It is not the only persistence layer. All durable events must also be stored through `Tet.Store`.

## Explain API

`Tet.explain/2` returns a concise, auditable summary:

```text
session metadata
user request summary
files inspected
context snapshot id
tools used
blocked tools and reasons
patches proposed
approvals created/resolved
files changed
verifiers run
latest result
artifact references
policy denials
errors
```

This powers `tet explain SESSION_ID` and optional Phoenix explanation views.
