# 08 — CLI Contract, JSON Output, and Exit Codes

## CLI principle

The CLI is a thin adapter. It parses user intent, calls `Tet.*`, renders results, and exits with deterministic status codes.

## Human output

Human output should be concise:

- show what happened;
- show next action;
- show IDs;
- show relevant files;
- show policy blocks clearly;
- avoid dumping private artifacts by default.

## JSON output

Most noninteractive commands support `--json`.

Commands:

```text
workspace info
session new
session list
session show
ask
explore
edit
approvals
patch approve
patch reject
patch rollback
verify
status
explain
prompt debug
events tail
```

## JSON response envelope

```json
{
  "ok": true,
  "type": "session.created",
  "data": {},
  "events": [],
  "warnings": [],
  "artifacts": []
}
```

Error envelope:

```json
{
  "ok": false,
  "error": {
    "reason": "workspace_not_trusted",
    "message": "Workspace is not trusted for execute mode.",
    "details": {}
  }
}
```

## Exit codes

```text
0  success
1  general failure
2  policy blocked
3  waiting for approval
4  provider error
5  tool error
6  verifier failed
7  invalid CLI usage / wrong mode
8  workspace not trusted
9  workspace not initialized
10 approval expired or invalid
11 patch apply failed
12 rollback failed
13 storage error
14 configuration error
```

## `tet explain`

`tet explain SESSION_ID` should answer:

```text
What was requested?
What mode was used?
What did the model see?
Which files were inspected?
Which tools ran?
Which tools were blocked?
What patch was proposed?
Who approved/rejected it?
What changed on disk?
Which verifier ran?
What failed?
Where are the artifacts?
```

## `tet status`

Should show:

```text
session id/mode/status
workspace trust state
git branch/commit/dirty state
active task
pending approval
last provider call
recent tool runs
last patch result
last verifier result
artifact summary
next recommended action
```

## Interactive chat

`tet chat SESSION_ID` is a REPL. For v1:

- chat sessions have no tools;
- Ctrl-D exits cleanly;
- streaming text is shown as it arrives;
- final assistant message is persisted;
- provider errors are typed and shown clearly.

## Noninteractive behavior

In noninteractive commands:

- never prompt for approval inline unless a future `--yes` is explicitly designed;
- `tet edit` exits with code 3 when approval is pending;
- `tet patch approve` is the explicit approval action;
- do not apply patches implicitly from `tet edit`.
