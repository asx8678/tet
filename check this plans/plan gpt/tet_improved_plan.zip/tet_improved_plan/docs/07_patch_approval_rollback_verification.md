# 07 — Patch Approval, Rollback, and Verification

## Patch principle

The agent may propose patches. Only the runtime may apply an approved patch. No patch writes occur before approval.

## Proposal workflow

```text
agent proposes unified diff
→ normalize and validate diff
→ policy checks mode/trust/path/size/pending approvals
→ compute patch hash
→ compute target file list
→ compute before-file hashes when files exist
→ save diff artifact
→ save optional file snapshots
→ create patch_set record
→ create pending approval
→ emit events
→ render approval id and diff preview
```

## Approval record

Approval should include:

```text
approval id
session id
workspace id
patch set id
diff artifact id
status: pending | approved | rejected | expired
created_at
expires_at
resolved_at
resolved_by
risk summary
reason
metadata
```

The original plan used only `pending`, `approved`, and `rejected`. The improved plan adds `expired` or treats expiration as a derived state. Either is acceptable, but the CLI must refuse expired approvals.

## Patch set record

Patch set should include:

```text
patch id
session id
workspace id
tool_run id
diff artifact id
patch sha256
target files
before hashes
snapshot artifact ids
apply status
apply result metadata
rollback artifact id
created_at
applied_at
rolled_back_at
```

## Apply preflight

Before applying, runtime must verify:

```text
workspace trusted
session mode execute
approval approved
approval not expired
approval belongs to session/workspace
patch hash unchanged
same diff artifact
target paths inside workspace
no forbidden .tet/.git path
file hashes unchanged or configured dirty policy allows it
patch applies cleanly
no other write tool running for session
```

## Dirty Git policy

Recommended default: practical mode.

```text
Allow edits in dirty worktrees, but:
  - record git status before apply;
  - warn the user;
  - snapshot touched files;
  - record target file before-hashes;
  - refuse if target files changed after proposal unless --allow-changed-targets is passed.
```

Alternative strict mode can be enabled:

```toml
[patch]
dirty_worktree_policy = "refuse"
```

## Rollback

Rollback should be conservative.

`tеt patch rollback PATCH_ID` should:

1. find patch set;
2. ensure it was applied;
3. verify rollback is safe;
4. restore snapshots or apply reverse patch;
5. create rollback artifact/receipt;
6. emit events;
7. recommend running verifier again.

If rollback cannot be safely applied, Tet should print the snapshot artifact paths and manual recovery instructions.

## Verification

Verifier commands are named allowlist entries.

Example:

```toml
[verification.allowlist.mix_test]
command = ["mix", "test"]
timeout_ms = 180000
max_stdout_bytes = 200000
max_stderr_bytes = 200000
env_allowlist = ["MIX_ENV", "PATH", "HOME"]
working_dir = "."
fail_blocks_success = true
```

## Verifier run record

Persist:

```text
verifier name
command argv
working directory
started_at
finished_at
timeout_ms
exit_code
status: success | failure | timeout | error
stdout artifact id
stderr artifact id
redaction metadata
git status after run
```

## Output handling

Verifier output should be:

- capped;
- saved as artifacts;
- redacted before display;
- summarized in status/explain;
- never used as permission to run arbitrary commands.
