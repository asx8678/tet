# 09 — Testing, Acceptance, and Release

## Test layers

### Core unit tests

Test pure structs, IDs, events, redactor, policy contracts, patch validation, and error shapes.

### Policy/security tests

Test path escapes, symlink escapes, `.tet/` protection, mode restrictions, patch size caps, file size caps, verifier allowlist, redaction, and env scrubbing.

### Store contract tests

Run the same tests against memory and SQLite stores:

- create workspace;
- create session;
- append events with monotonic sequence;
- create approval transactionally with patch/artifact;
- resolve approval;
- list sessions/events/approvals;
- record provider calls and verifier runs;
- handle DB lock/error cases.

### Runtime integration tests

Test session worker lifecycle, event publishing, provider fake, tool execution, prompt debug, context snapshots, patch proposal, approval apply, verifier run, rollback artifacts.

### CLI tests

Test commands with golden output and JSON schemas.

### Release closure tests

Build `tet_standalone` and verify no Phoenix/Plug/Cowboy/LiveView closure.

### Phoenix removability tests

Temporarily remove or exclude web app and rerun compile/test/release.

## Required fake provider

Implement a deterministic fake provider for tests:

```text
returns fixed assistant text
returns a configured tool call
streams predictable deltas
can simulate timeout/error/rate-limit/malformed tool call
```

## Required test repository fixtures

Create fixtures:

```text
clean_elixir_repo
dirty_repo
repo_with_symlink_escape
repo_with_large_file
repo_with_binary_file
repo_with_env_secret
repo_with_invalid_patch
repo_with_failing_verifier
```

## Acceptance demo

The demo script in `implementation/demo_v1.sh` must pass in a real local repository using the standalone release.

## Release profiles

```text
tet_standalone  core + runtime + CLI + SQLite store + selected provider
tet_runtime_only core + runtime + store, no CLI/web
tet_web optional future profile with Phoenix adapter
```

## Standalone release acceptance

Pass:

```bash
MIX_ENV=prod mix release tet_standalone --overwrite
_build/prod/rel/tet_standalone/bin/tet doctor
implementation/acceptance_runner.sh
```

Fail release if standalone contains:

```text
phoenix
phoenix_live_view
phoenix_pubsub
plug
cowboy
bandit, if not intentionally allowed for web only
TetWeb.*
```

## Package target

For v1, produce:

```text
tet_standalone.tar.gz
SHA256 checksum
install script, optional
```

Homebrew/asdf/Docker packaging can wait until after CLI v1 works.
