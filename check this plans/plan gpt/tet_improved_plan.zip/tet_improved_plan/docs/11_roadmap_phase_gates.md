# 11 — Roadmap and Phase Gates

## Phase 0 — Skeleton and dependency guards

Deliver:

- umbrella project;
- apps: core, runtime, CLI, store memory, store SQLite;
- initial guard scripts;
- forbidden dependency tests.

Exit when:

- `mix compile --warnings-as-errors` passes;
- guard scripts pass;
- standalone release skeleton has no web closure.

## Phase 1 — Core contracts

Deliver:

- domain structs;
- command structs;
- errors;
- event types;
- policy reason atoms;
- provider/tool/store behaviours;
- redactor interface;
- patch validation primitives.

Exit when:

- core tests pass;
- core has no runtime/CLI/store/web deps.

## Phase 2 — Policy and security tests

Deliver:

- path resolver tests;
- symlink escape tests;
- `.tet/` protection tests;
- mode matrix tests;
- verifier allowlist tests;
- redaction tests.

Exit when:

- adversarial policy matrix passes.

## Phase 3 — Store behavior and memory store

Deliver:

- store contract tests;
- memory store implementation;
- event sequence assignment;
- approval transaction contract.

Exit when:

- memory store passes store contract tests.

## Phase 4 — SQLite and workspace init

Deliver:

- SQLite schema/migrations;
- artifact writer;
- `.tet/` workspace creation;
- config parser;
- `tet init` runtime support.

Exit when:

- SQLite store passes same store contract tests;
- `.tet/` layout is created correctly.

## Phase 5 — Runtime foundation

Deliver:

- `Tet` facade;
- supervision tree;
- event bus;
- session registry;
- session worker;
- runtime command dispatcher.

Exit when:

- session create/status/list works through facade;
- events persist and publish.

## Phase 6 — CLI foundation

Deliver:

- argv parser;
- renderers;
- JSON envelope;
- exit code mapper;
- `doctor`, `init`, `workspace`, `session`, `status`, `events tail`.

Exit when:

- CLI works against memory and SQLite test configs.

## Phase 7 — Provider, prompt debug, chat mode

Deliver:

- provider behavior;
- fake provider;
- prompt composer;
- prompt debug;
- provider call persistence;
- `tet ask` and `tet chat`.

Exit when:

- chat mode works with fake and one real configured provider;
- prompt debug artifact exists.

## Phase 8 — Context builder and explore mode

Deliver:

- `.tetignore`;
- context snapshot;
- read tools;
- search tool;
- git status/diff tools;
- explore command.

Exit when:

- read-only mode cannot write;
- context snapshot explains included/skipped files.

## Phase 9 — Patch proposal and approvals

Deliver:

- unified diff validation;
- patch set record;
- diff artifact;
- before hashes;
- file snapshots;
- approval expiration;
- approvals CLI.

Exit when:

- edit creates pending approval and exits code 3;
- no disk writes occur before approval.

## Phase 10 — Patch application and rollback

Deliver:

- apply preflight;
- patch applier;
- dirty-git policy;
- rollback artifacts;
- `patch approve`, `patch reject`, `patch rollback`.

Exit when:

- approved patch applies;
- rejected patch changes nothing;
- unsafe patch is refused;
- rollback is possible or manual recovery is documented.

## Phase 11 — Verification

Deliver:

- verifier allowlist parser;
- scrubbed env;
- timeout/output caps;
- verifier run persistence;
- stdout/stderr artifacts;
- `tet verify`.

Exit when:

- allowlisted verifier runs;
- raw shell is rejected;
- timeout and output caps work.

## Phase 12 — End-to-end acceptance

Deliver:

- demo script;
- acceptance runner;
- release closure test;
- documentation updates.

Exit when:

- `tet_standalone` release passes all acceptance checks.

## Phase 13 — Optional Phoenix adapter

Start only after Phase 12.

Deliver:

- LiveView dashboard;
- session timeline;
- approval panel;
- verifier output;
- prompt debug view;
- facade-only guard.

Exit when:

- web UI works;
- standalone release remains Phoenix-free.
