# 12 — Risks and Mitigations

## Risk: scope creep before CLI v1

Mitigation: enforce MVP cut line. Phoenix, Postgres, remote execution, and multi-agent features wait until standalone acceptance passes.

## Risk: unsafe file access

Mitigation: path resolver, symlink checks, `.tet/` protection, `.git/` block, file size caps, binary detection, adversarial tests.

## Risk: secret leakage to providers

Mitigation: `.tetignore`, redaction before provider calls, context snapshots, private artifact defaults, redaction tests.

## Risk: untrusted patch application

Mitigation: diff-only proposal, explicit approval, approval expiration, patch hashes, before-file hashes, snapshots, preflight checks, rollback artifacts.

## Risk: arbitrary command execution sneaks in

Mitigation: verifier allowlist only, argv arrays not shell strings, env scrubbing, command name policy, tests for injection attempts.

## Risk: Phoenix dependency leaks into standalone runtime

Mitigation: dependency guards from day zero, xref checks, release closure checks, runtime smoke tests, removability tests.

## Risk: agent decisions become impossible to debug

Mitigation: event log, provider call records, prompt debug, context snapshots, tool runs, artifacts, `tet explain`.

## Risk: SQLite locking or corruption

Mitigation: transaction discipline, busy timeout, retry policy for benign locks, migration checks in `doctor`, backup guidance.

## Risk: provider variability makes tests flaky

Mitigation: deterministic fake provider for tests and demos; real provider tests are opt-in smoke tests.

## Risk: verifier output is huge or sensitive

Mitigation: output byte caps, redaction before display, artifact storage, summarized CLI output.

## Risk: dirty worktrees make rollback hard

Mitigation: dirty-git policy, before hashes, snapshots, warnings, refuse changed targets by default after proposal.
