# 05 — Context Builder, Prompt Composer, and Provider Layer

## Problem

Coding agents fail silently when they select the wrong context, leak secrets, or hide what the model saw. Tet should make context selection and prompt assembly explicit, inspectable, and persisted.

## Context builder responsibilities

The context builder runs before provider calls in explore and execute modes.

It must:

- respect `.gitignore`;
- respect `.tetignore`;
- skip `.git/` always;
- skip `.tet/` internals by default;
- skip generated dependency/build/cache folders;
- detect binary files;
- truncate large text files;
- cap total context bytes/tokens;
- prefer files named by the user;
- prefer files recently touched by tool results;
- include git status/diff summaries when useful;
- redact secrets before provider calls;
- emit a context snapshot artifact.

## Default skipped paths

```text
.git/
.tet/
node_modules/
deps/
_build/
target/
dist/
build/
coverage/
.cache/
.env
.env.*
*.pem
*.key
*.p12
*.pfx
```

## `.tetignore`

Users can add project-specific exclusions. See:

```text
implementation/tetignore_example
```

## Context snapshot contents

Each provider call should link to a context snapshot containing:

```text
requested user prompt
mode
workspace root hash, not raw path when privacy is desired
files included
files skipped and reasons
files truncated
binary files summarized
redaction patterns found
estimated token budget
final context byte count
context hash
```

## Prompt layers

Final provider messages are assembled from ordered layers:

1. base system prompt;
2. mode prompt;
3. safety and policy instructions;
4. tool cards;
5. workspace summary;
6. git status/diff summary when allowed;
7. selected file snippets;
8. recent conversation window;
9. active task details;
10. user message.

## Prompt files

Workspace overrides live in:

```text
.tet/prompts/
  base.md
  mode_chat.md
  mode_explore.md
  mode_execute.md
  policy.md
  tool_cards.md
  verifier.md
```

Runtime defaults are bundled in `tet_runtime`.

## Prompt debug

`tet prompt debug SESSION_ID --save` should produce:

```text
prompt_debug artifact
prompt hash
layer list
included message ids
included file snippets
redaction summary
estimated tokens
provider/model target
```

The debug view must not show unredacted secrets by default.

## Provider behavior

The provider behavior should normalize all model interactions:

```elixir
@callback stream_chat(request, opts) ::
  {:ok, Enumerable.t()} | {:error, Tet.Error.t()}

@callback chat(request, opts) ::
  {:ok, Tet.Provider.Response.t()} | {:error, Tet.Error.t()}
```

Provider output events should be normalized into:

```text
text_delta
tool_call_delta
tool_call_completed
usage
finish
error
```

## Provider call persistence

Persist for every provider call:

```text
provider name
model
request id
session id
message id
prompt hash
context snapshot id
prompt debug artifact id
raw request artifact id, optional
raw response artifact id, optional
started_at
finished_at
latency_ms
input_tokens
output_tokens
total_tokens
estimated_cost
finish_reason
status
error_reason
redaction metadata
```

## Provider controls

Configurable controls:

```text
provider timeout
max input tokens
max output tokens
temperature
top_p if supported
streaming on/off
max retries
retry backoff
save provider payloads on/off
redact before provider call on/off
```

## Error handling

Provider errors must become typed `Tet.Error` values and durable events:

```text
provider.timeout
provider.rate_limited
provider.auth_failed
provider.malformed_response
provider.tool_call_invalid
provider.stream_interrupted
provider.unavailable
```

The CLI should never show raw provider secrets or full provider payloads by default.
