# 02 — Architecture and Dependency Boundaries

## Architectural rule

```text
User adapters parse and render.
Runtime orchestrates.
Core defines pure contracts.
Adapters implement behaviours.
Phoenix is optional and removable.
```

## App responsibilities

### `tet_core`

Pure library. No processes, Ecto repos, terminal rendering, Phoenix, Plug, runtime modules, or store implementations.

Owns:

- domain structs;
- command structs;
- events and event types;
- error types and reason atoms;
- pure policy contracts;
- provider, tool, store, redactor, and patch behaviours;
- ID helpers;
- validation helpers that do not touch the filesystem.

### `tet_runtime`

OTP orchestration layer. Owns all side effects.

Owns:

- public `Tet` facade;
- runtime application and supervision tree;
- session registry and session workers;
- event bus;
- store dispatcher;
- prompt composer;
- context builder;
- provider adapter loading;
- concrete local tools;
- path resolver;
- patch applier;
- verifier runner;
- artifact writer;
- telemetry.

### `tet_cli`

Thin terminal adapter.

Owns:

- argument parsing;
- terminal rendering;
- JSON output rendering;
- interactive REPL loop;
- exit code mapping.

Must not own:

- policies;
- patch application;
- provider calls;
- prompt composition;
- storage writes;
- verifier execution;
- runtime internals.

### `tet_store_memory`

Contract-test and runtime-test store.

Depends only on `tet_core`.

### `tet_store_sqlite`

Default local store.

Owns migrations, schema mapping, and SQLite repo/processes. It depends on `tet_core` and SQLite/Ecto libraries only.

### `tet_store_postgres`

Future optional server/team store. Not required in v1 except as a design target.

### `tet_web_phoenix`

Future optional UI adapter. It calls `Tet.*`, subscribes to events, and renders data. It does not own runtime behavior.

## Standalone supervision tree

```text
Tet.Application
├── Tet.Telemetry
├── Tet.Config.Loader
├── Tet.EventBus
├── Tet.Store.Supervisor
├── Tet.Artifact.Supervisor
├── Tet.Runtime.SessionRegistry
├── Tet.Runtime.SessionSupervisor
├── Tet.Agent.RuntimeSupervisor
├── Tet.Tool.TaskSupervisor
└── Tet.Verification.TaskSupervisor
```

No Phoenix endpoint, Plug, Cowboy, LiveView, or Phoenix.PubSub process may appear in the standalone tree.

## Dependency guards

Every CI run must check:

1. mix dependency closure;
2. compile-time xref graph;
3. source grep for forbidden module names;
4. runtime smoke boot;
5. release closure;
6. Phoenix removability test;
7. facade-only usage for UI apps.

## Removability test

The optional web app must be removable without breaking the standalone release:

```bash
mv apps/tet_web_phoenix /tmp/tet_web_phoenix_disabled
mix compile --warnings-as-errors
mix test
MIX_ENV=prod mix release tet_standalone --overwrite
```

If this fails, Phoenix is not optional.
