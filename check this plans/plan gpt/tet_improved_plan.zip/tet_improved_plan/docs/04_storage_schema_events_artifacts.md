# 04 — Storage, Schema, Events, and Artifacts

## Storage principle

Tet v1 uses local SQLite by default. Storage must be accessed through a `Tet.Store` behavior so memory and future Postgres stores can implement the same contract.

## Workspace layout

```text
repo-root/.tet/
  tet.sqlite
  config.toml
  prompts/
  artifacts/
    diffs/
    stdout/
    stderr/
    file_snapshots/
    prompt_debug/
    provider_payload/
    context_snapshots/
    patch_receipts/
  cache/
  locks/
```

## New v1 entities added to the original plan

The original plan had workspaces, sessions, tasks, messages, tool runs, approvals, artifacts, and events. The improved plan adds:

```text
provider_calls      records model interactions, usage, latency, request/response artifact ids
verifier_runs       records verifier command, exit code, status, output artifacts, timeout
context_snapshots   records files included/skipped/truncated/redacted before provider call
patch_sets          records diff hash, target files, before hashes, apply/rollback metadata
schema_migrations   records local schema version
```

## Event log

Events are append-only and ordered by `(session_id, seq)`.

Rules:

- never mutate event payloads after write;
- event sequence numbers are monotonic per session;
- each significant side effect emits an event;
- blocked actions emit events too;
- events contain references to artifacts, not large payloads.

## Artifact rules

Each artifact records:

```text
kind
workspace_id
session_id
relative path inside .tet/artifacts
sha256
size_bytes
mime_type or media_type
redaction status
created_at
metadata JSON
```

Large content is stored on disk, not inline. The database stores metadata and references.

## Artifact privacy

Default privacy level:

```text
diffs: local-visible
stdout/stderr: local-visible, redacted before display
file_snapshots: private
prompt_debug: private
provider_payload: private
context_snapshots: private
patch_receipts: local-visible
```

CLI output should show artifact IDs and safe summaries by default, not dump private artifacts unless the user explicitly requests it.

## Schema versioning

`schema_migrations` stores applied versions. `tet doctor` checks schema state.

Recommended migration strategy:

```text
001_initial_core.sql
002_provider_context_patch.sql
003_indexes.sql
```

For v1, a single `sqlite_schema_v1.sql` is acceptable, but code should be structured as migrations.

## Store behavior additions

The store behavior should include operations for:

```text
provider_calls
context_snapshots
patch_sets
verifier_runs
artifact lookups by kind/session
atomic event append with sequence assignment
approval resolution in a transaction
patch approval expiration scan
```

## Transaction boundaries

These operations must be transactional:

- create session + initial event;
- persist user message + event;
- persist provider call start + event;
- create patch set + diff artifact + pending approval + events;
- approve/reject approval + event;
- apply patch result + patch receipt + events;
- verifier run + stdout/stderr artifacts + events.

## SQLite schema

See:

```text
implementation/sqlite_schema_v1.sql
```
