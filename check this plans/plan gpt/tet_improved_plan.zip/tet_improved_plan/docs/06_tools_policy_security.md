# 06 — Tools, Policy, and Security

## Tool principle

No tool may bypass policy.

```text
provider tool intent
→ normalize args
→ policy check
→ allow / require approval / block
→ persist tool run and event
→ execute only if allowed
```

## v1 tools

Read tools:

```text
list_dir(path)
read_file(path)
search_text(query, path)
git_status()
git_diff()
```

Patch tools:

```text
propose_patch(diff)
apply_approved_patch(approval_id)
```

Verifier tool:

```text
run_command(verifier_name)
```

No arbitrary shell, no direct file write, no delete file, no network tool, no package installation.

## Policy checks

Every tool check includes:

```text
workspace trust state
session mode
active task
tool name
normalized args
path safety
file size limits
patch size limits
pending approval state
command allowlist
redaction state when relevant
```

## Path policy

Path resolution must:

1. expand relative paths against workspace root;
2. normalize `.` and `..`;
3. inspect symlinks in each ancestor;
4. resolve final path;
5. compare against canonical workspace root;
6. apply OS-aware case sensitivity;
7. block `.git/` internals;
8. block `.tet/` internals by default;
9. reject device paths such as `/proc`, `/sys`, or platform equivalents when outside workspace.

Blocked cases:

```text
../outside.txt
repo/subdir/../../outside.txt
/tmp/secret.txt
/proc/self/environ
symlink_to_outside/file.txt
.tet/tet.sqlite direct read by agent
.git/config direct read by agent
```

## `.tet/` protection

Policy:

```text
Runtime may write .tet/.
Agent tools may not patch .tet/ by default.
Agent tools may not read private .tet/artifacts/ by default.
CLI may display safe summaries of .tet state through Tet.* facade.
```

A future explicit config-edit workflow can allow user-approved changes to `.tet/config.toml`, but it is not part of the ordinary patch tool.

## Redaction stages

Redact at four stages:

1. before provider call;
2. before artifact persistence when configured;
3. before CLI/web display;
4. before logs/errors.

Patterns:

```text
API keys
bearer tokens
private key blocks
.env secret values
authorization headers
database URLs with credentials
cloud credentials
SSH keys
webhook secrets
```

## Environment scrubbing

Verifier commands run with a scrubbed environment.

Default allowed variables:

```text
PATH
HOME
MIX_ENV
LANG
LC_ALL
TERM
```

Provider credentials should never be passed to verifier child processes unless explicitly allowlisted.

## Limits

Default suggested limits:

```text
max_file_read_bytes = 262144
max_search_results = 100
max_search_bytes = 524288
max_context_bytes = 1048576
max_patch_bytes = 524288
max_tool_iterations = 6
max_concurrent_tools = 4
provider_timeout_ms = 120000
verifier_timeout_ms = 120000
max_stdout_bytes = 200000
max_stderr_bytes = 200000
approval_expiry_minutes = 60
```

## Policy test priority

Policy tests should be implemented before provider/tool integration becomes complex. See:

```text
implementation/policy_test_matrix.md
```
