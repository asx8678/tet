# 10 — Optional Phoenix Adapter

## Rule

Phoenix is a UI adapter only. It must never own runtime logic.

## Build timing

Do not implement Phoenix before the standalone CLI v1 passes acceptance.

## Allowed Phoenix responsibilities

Phoenix may:

- render dashboard;
- render session timeline;
- render transcript;
- render tool runs;
- render approval diffs;
- call `Tet.approve_patch/2` and `Tet.reject_patch/2`;
- render verifier output;
- render prompt debug;
- subscribe to `Tet` events through the facade;
- provide browser forms that call `Tet.*`.

## Forbidden Phoenix responsibilities

Phoenix must not:

- call providers directly;
- compose prompts;
- execute tools;
- enforce policies;
- apply patches;
- run verifiers;
- own the event bus;
- own storage schemas for Tet domain objects;
- directly query SQLite/Postgres Tet tables for business logic;
- start Tet session workers outside runtime;
- use Phoenix.PubSub as the Tet runtime event bus.

## UI data access

Preferred:

```text
LiveView calls Tet.status/2, Tet.explain/2, Tet.list_events/2, Tet.list_approvals/2.
```

If more data is needed, add a safe public facade function.

## Phoenix release profile

`tet_web` may include:

```text
tet_core
tet_runtime
tet_store_sqlite or tet_store_postgres
tet_web_phoenix
Phoenix dependencies
```

`tet_standalone` must not include any web dependencies.

## Phoenix acceptance

When Phoenix is added:

- CLI tests still pass;
- runtime tests still pass;
- standalone release closure remains clean;
- removing `tet_web_phoenix` does not break `tet_standalone`;
- LiveViews call only the public facade.
