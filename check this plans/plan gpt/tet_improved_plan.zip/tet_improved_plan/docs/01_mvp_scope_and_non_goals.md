# 01 — MVP Scope and Non-Goals

## MVP objective

Ship a standalone CLI release that proves the complete safe-agent loop:

```text
init workspace
→ create session
→ chat or inspect repo
→ request edit
→ propose diff
→ require approval
→ apply approved patch
→ run allowlisted verifier
→ show audit trail
```

## Required v1 outcomes

A user can:

- initialize a repo with `.tet/` state;
- mark a workspace trusted;
- create chat, explore, and execute sessions;
- ask questions in chat mode without repo access;
- inspect repo files in explore mode with read-only tools;
- ask for an edit in execute mode;
- review a unified diff before anything is written;
- approve or reject the patch;
- run a named verifier from config;
- inspect status, events, artifacts, and an explanation of what happened.

## Required v1 commands

```text
tet doctor
tet init
tet workspace trust
tet workspace info
tet session new
tet session list
tet session show
tet chat
tet ask
tet explore
tet edit
tet approvals
tet patch approve
tet patch reject
tet patch rollback
tet verify
tet status
tet explain
tet prompt debug
tet events tail
```

## v1 deferred features

Do not implement before the standalone CLI passes acceptance:

```text
Phoenix UI
Postgres production mode
daemon / attach mode
TUI
Prompt Lab
multi-agent planner
worker agents
remote execution
SSH execution
cloud sync
team collaboration
long-term memory scoring
automatic repair loop
package install tools
network tools
arbitrary shell tools
raw file write/delete tools
```

## MVP quality bar

The CLI v1 is not done until:

- all policy tests pass;
- the end-to-end demo passes in a real repo;
- the standalone release builds without web dependencies;
- artifacts and events are enough to explain every important decision;
- patch application can be rejected, applied, or rolled back using recorded artifacts;
- verifier output is stored, capped, and redacted;
- `.tet/` data is protected from agent-proposed edits.

## Product cut line

If a feature does not help one of these v1 flows, defer it:

1. safe conversation;
2. safe repository inspection;
3. safe patch proposal;
4. explicit approval;
5. controlled verification;
6. auditable persistence.
